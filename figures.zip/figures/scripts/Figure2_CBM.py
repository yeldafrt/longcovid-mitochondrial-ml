"""
Figure 2 - Model Performance (Panelled: A, B, C)
Computers in Biology and Medicine (Elsevier) Guidelines:
- Combination bitmapped line/halftones: min 500 dpi
- Full page width: min 3740 pixels at 500 dpi
- Format: TIFF, JPG, PNG
- RGB color mode
- Using 600 DPI for safety margin
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import json

# Load data
results_dir = '/home/ubuntu/model_project/results'

# ROC curves
with open(f'{results_dir}/plot_data/roc_curves.json') as f:
    roc_data = json.load(f)

# PR curves
with open(f'{results_dir}/plot_data/precision_recall_curves.json') as f:
    pr_data = json.load(f)

# Model configuration
models_order = ['Random_Forest', 'Gradient_Boosting', 'XGBoost', 'SVM']
model_labels = {
    'Random_Forest': 'Random Forest',
    'Gradient_Boosting': 'Gradient Boosting',
    'XGBoost': 'XGBoost',
    'SVM': 'SVM (RBF)',
    'Logistic_Regression': 'Logistic Regression'
}

# Color palette for models
model_colors = {
    'Random_Forest': '#1565C0',
    'Gradient_Boosting': '#E65100',
    'XGBoost': '#2E7D32',
    'SVM': '#6A1B9A',
    'Logistic_Regression': '#757575'
}

# Create figure with 3 panels - 600 DPI for journal
fig, axes = plt.subplots(1, 3, figsize=(7.09, 2.8), dpi=600)

# ===== Panel (A): ROC Curves =====
ax = axes[0]
for model in models_order + ['Logistic_Regression']:
    fpr = np.load(f'{results_dir}/npy_arrays/roc_fpr_{model}.npy')
    tpr = np.load(f'{results_dir}/npy_arrays/roc_tpr_{model}.npy')
    auc_val = roc_data[model]['auc']
    label = f"{model_labels[model]} ({auc_val:.3f})"
    ax.plot(fpr, tpr, color=model_colors[model], linewidth=1.5, label=label)

ax.plot([0, 1], [0, 1], 'k--', linewidth=0.8, alpha=0.5)
ax.set_xlabel('False Positive Rate', fontsize=8)
ax.set_ylabel('True Positive Rate', fontsize=8)
ax.set_title('ROC Curves', fontsize=9, fontweight='bold', pad=8)
ax.legend(fontsize=5.5, loc='lower right', framealpha=0.9)
ax.tick_params(labelsize=7)
ax.set_xlim([-0.02, 1.02])
ax.set_ylim([-0.02, 1.02])
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Panel label
ax.text(-0.15, 1.08, '(A)', transform=ax.transAxes, fontsize=10, fontweight='bold')

# ===== Panel (B): Precision-Recall Curves =====
ax = axes[1]
for model in models_order + ['Logistic_Regression']:
    precision = np.load(f'{results_dir}/npy_arrays/pr_precision_{model}.npy')
    recall = np.load(f'{results_dir}/npy_arrays/pr_recall_{model}.npy')
    ap_val = pr_data[model]['average_precision']
    label = f"{model_labels[model]} ({ap_val:.3f})"
    ax.plot(recall, precision, color=model_colors[model], linewidth=1.5, label=label)

ax.set_xlabel('Recall', fontsize=8)
ax.set_ylabel('Precision', fontsize=8)
ax.set_title('Precision-Recall Curves', fontsize=9, fontweight='bold', pad=8)
ax.legend(fontsize=5.5, loc='lower left', framealpha=0.9)
ax.tick_params(labelsize=7)
ax.set_xlim([-0.02, 1.02])
ax.set_ylim([-0.02, 1.02])
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Panel label
ax.text(-0.15, 1.08, '(B)', transform=ax.transAxes, fontsize=10, fontweight='bold')

# ===== Panel (C): Confusion Matrix (Best Model - Random Forest) =====
ax = axes[2]
cm = np.load(f'{results_dir}/npy_arrays/confusion_matrix_Random_Forest.npy')

# Normalize for color mapping
cm_norm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

# Plot heatmap
im = ax.imshow(cm_norm, interpolation='nearest', cmap='Blues', vmin=0, vmax=1)

# Add text annotations
for i in range(2):
    for j in range(2):
        color = 'white' if cm_norm[i, j] > 0.5 else 'black'
        ax.text(j, i, f'{cm[i, j]}\n({cm_norm[i, j]*100:.1f}%)',
                ha='center', va='center', fontsize=8, color=color, fontweight='bold')

ax.set_xticks([0, 1])
ax.set_yticks([0, 1])
ax.set_xticklabels(['Recovered/\nHealthy', 'Persistent'], fontsize=7)
ax.set_yticklabels(['Recovered/\nHealthy', 'Persistent'], fontsize=7)
ax.set_xlabel('Predicted Label', fontsize=8)
ax.set_ylabel('True Label', fontsize=8)
ax.set_title('Confusion Matrix (RF)', fontsize=9, fontweight='bold', pad=8)

# Panel label
ax.text(-0.15, 1.08, '(C)', transform=ax.transAxes, fontsize=10, fontweight='bold')

# Colorbar
cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
cbar.ax.tick_params(labelsize=6)

plt.tight_layout(pad=1.0)

# Save in all formats at 600 DPI
plt.savefig('/home/ubuntu/Figure_2.tiff', dpi=600, format='tiff',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_2.png', dpi=600, format='png',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_2.jpg', dpi=600, format='jpeg',
            bbox_inches='tight', facecolor='white', pil_kwargs={'quality': 95})
plt.close()

# Convert RGBA to RGB if needed
from PIL import Image
import os

for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_2.{fmt}'
    img = Image.open(filepath)
    if img.mode == 'RGBA':
        rgb_img = Image.new('RGB', img.size, (255, 255, 255))
        rgb_img.paste(img, mask=img.split()[3])
        rgb_img.save(filepath, dpi=(600, 600), quality=95 if fmt == 'jpg' else None)
    elif img.mode != 'RGB':
        img.convert('RGB').save(filepath, dpi=(600, 600))

# Final verification
print("Figure 2 saved successfully for Computers in Biology and Medicine!")
print("=" * 60)
for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_2.{fmt}'
    img = Image.open(filepath)
    size_mb = os.path.getsize(filepath) / 1024 / 1024
    print(f"  {fmt.upper():4s} - {img.size[0]}x{img.size[1]} px, Mode: {img.mode}, "
          f"DPI: {img.info.get('dpi', 'N/A')}, Size: {size_mb:.1f} MB")

w = img.size[0]
print(f"\nFull page width requirement (min 3740 px at 500 dpi): {'PASS' if w >= 3740 else 'FAIL'} ({w} px)")
print(f"DPI: 600 (requirement: min 500 for combination figures)")
