"""
Figure 1 - Study Workflow and Data Processing Pipeline
Computers in Biology and Medicine (Elsevier) Guidelines:
- Color/grayscale photographs: min 300 dpi
- Combinations bitmapped line/halftones: min 500 dpi
- Single column width: min 1063 pixels (89mm)
- Full page width: min 2244 pixels (180mm)
- This is a combination figure (line + color fills) → 500 dpi, full page width
- Format: TIFF and PNG
- Full page width at 500 dpi = 3543 pixels minimum
- We'll use 600 dpi for safety margin → ~4252 pixels width
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
import numpy as np

# Figure setup - Full page width: 180mm = 7.09 inches
# Using 600 DPI for combination line/halftone (exceeds 500 dpi minimum)
fig, ax = plt.subplots(1, 1, figsize=(7.09, 6.0), dpi=600)
ax.set_xlim(0, 100)
ax.set_ylim(0, 75)
ax.axis('off')

# Color palette - RGB mode (journal requirement)
colors = {
    'data': '#E3F2FD',
    'data_border': '#1565C0',
    'preprocess': '#FFF3E0',
    'preprocess_border': '#E65100',
    'classify': '#F3E5F5',
    'classify_border': '#6A1B9A',
    'ml': '#FFEBEE',
    'ml_border': '#B71C1C',
    'validation': '#E0F7FA',
    'validation_border': '#006064',
    'shap': '#F1F8E9',
    'shap_border': '#33691E',
}

def draw_box(ax, x, y, w, h, facecolor, edgecolor, linewidth=2):
    """Draw a rounded box"""
    box = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3",
                         facecolor=facecolor, edgecolor=edgecolor, linewidth=linewidth)
    ax.add_patch(box)

def draw_arrow(ax, x1, y1, x2, y2):
    """Draw an arrow between two points"""
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color='#424242', lw=2))

# ===== ROW 1: DATA ACQUISITION (top) =====
# Main container
draw_box(ax, 2, 62, 96, 12, colors['data'], colors['data_border'])

# Title
ax.text(50, 72.5, 'DATA ACQUISITION', ha='center', va='center',
        fontsize=10, fontweight='bold', color=colors['data_border'])
ax.text(50, 70.5, '6 Independent Cohorts (n = 343)', ha='center', va='center',
        fontsize=8, color='#424242')

# Bulk RNA-seq box
draw_box(ax, 4, 63, 44, 5.5, '#BBDEFB', colors['data_border'], linewidth=1.5)
ax.text(26, 66.8, 'Bulk RNA-seq (n = 322)', ha='center', va='center',
        fontsize=8, fontweight='bold', color='#1565C0')
ax.text(26, 64.8, 'GSE267625 (111) | GSE169687 (142)', ha='center', va='center',
        fontsize=6.5, color='#424242')
ax.text(26, 63.5, 'GSE152418 (34) | GSE222253 (35)', ha='center', va='center',
        fontsize=6.5, color='#424242')

# scRNA-seq box
draw_box(ax, 52, 63, 44, 5.5, '#BBDEFB', colors['data_border'], linewidth=1.5)
ax.text(74, 66.8, 'scRNA-seq (n = 21)', ha='center', va='center',
        fontsize=8, fontweight='bold', color='#1565C0')
ax.text(74, 64.8, 'GSE265753 (18, BD Rhapsody)', ha='center', va='center',
        fontsize=6.5, color='#424242')
ax.text(74, 63.5, 'GSE235938 (3, 10x Genomics)', ha='center', va='center',
        fontsize=6.5, color='#424242')

# ===== ARROW to ROW 2 =====
draw_arrow(ax, 50, 62, 50, 59.5)

# ===== ROW 2: PREPROCESSING =====
draw_box(ax, 2, 49, 96, 10, colors['preprocess'], colors['preprocess_border'])

# Title
ax.text(50, 57.5, 'DATA PREPROCESSING', ha='center', va='center',
        fontsize=10, fontweight='bold', color=colors['preprocess_border'])

# Sub-steps - 5 boxes
step_w = 17.5
step_h = 5
step_y = 50
gap = 1.2
start_x = 3.5

steps_text = [
    'Gene ID\nUnification\n(Ensembl\u2192Symbol)',
    'Pseudobulk\nConversion\n(Sum Aggregation)',
    'Dataset\nIntegration\n(18,335 Genes)',
    'Normalization\nlog\u2082(CPM + 1)',
    'Mito Gene Filter\nMitoCarta3.0\n(149 Genes)',
]

for i, text in enumerate(steps_text):
    x = start_x + i * (step_w + gap)
    draw_box(ax, x, step_y, step_w, step_h, '#FFE0B2', colors['preprocess_border'], linewidth=1.5)
    ax.text(x + step_w/2, step_y + step_h/2, text, ha='center', va='center',
            fontsize=7, color='#424242', multialignment='center', linespacing=1.2)

# Arrows between preprocessing steps
for i in range(4):
    x1 = start_x + (i+1) * (step_w + gap) - gap
    x2 = start_x + (i+1) * (step_w + gap)
    y_mid = step_y + step_h/2
    draw_arrow(ax, x1, y_mid, x2, y_mid)

# ===== ARROW to ROW 3 =====
draw_arrow(ax, 50, 49, 50, 46.5)

# ===== ROW 3: BINARY CLASSIFICATION + ML PIPELINE =====
# Binary Classification
draw_box(ax, 2, 35, 36, 11, colors['classify'], colors['classify_border'])
ax.text(20, 44.5, 'BINARY CLASSIFICATION', ha='center', va='center',
        fontsize=9, fontweight='bold', color=colors['classify_border'])
ax.text(20, 42.5, '149 Genes \u00d7 343 Samples', ha='center', va='center',
        fontsize=7, color='#424242')

# Class boxes
draw_box(ax, 4, 36, 15.5, 4.5, '#CE93D8', colors['classify_border'], linewidth=1.5)
ax.text(11.75, 38.25, 'Persistent\nn=164 (47.8%)', ha='center', va='center',
        fontsize=7, fontweight='bold', color='#4A148C', multialignment='center')

draw_box(ax, 21, 36, 15.5, 4.5, '#CE93D8', colors['classify_border'], linewidth=1.5)
ax.text(28.75, 38.25, 'Recovered/Healthy\nn=179 (52.2%)', ha='center', va='center',
        fontsize=7, fontweight='bold', color='#4A148C', multialignment='center')

# ML Pipeline
draw_box(ax, 41, 35, 57, 11, colors['ml'], colors['ml_border'])
ax.text(69.5, 44.5, 'MACHINE LEARNING PIPELINE', ha='center', va='center',
        fontsize=9, fontweight='bold', color=colors['ml_border'])

# ML sub-boxes
draw_box(ax, 43, 36, 26, 5.5, '#FFCDD2', colors['ml_border'], linewidth=1.5)
ax.text(56, 39.5, 'Model Comparison', ha='center', va='center',
        fontsize=7, fontweight='bold', color='#B71C1C')
ax.text(56, 37.5, 'RF | XGBoost | GB | SVM | LR', ha='center', va='center',
        fontsize=7, color='#424242')

draw_box(ax, 71, 36, 25, 5.5, '#FFCDD2', colors['ml_border'], linewidth=1.5)
ax.text(83.5, 39.5, 'Nested 5-Fold CV', ha='center', va='center',
        fontsize=7, fontweight='bold', color='#B71C1C')
ax.text(83.5, 37.5, '+ Hyperparameter Opt.', ha='center', va='center',
        fontsize=7, color='#424242')

# Arrow from classification to ML
draw_arrow(ax, 38, 40.5, 41, 40.5)
# Arrow between ML sub-boxes
draw_arrow(ax, 69, 38.75, 71, 38.75)

# ===== ARROW to ROW 4 =====
draw_arrow(ax, 50, 35, 50, 32)

# ===== ROW 4: VALIDATION + EXPLAINABILITY =====
# Robustness Validation
draw_box(ax, 2, 18, 47, 13.5, colors['validation'], colors['validation_border'])
ax.text(25.5, 30, 'ROBUSTNESS VALIDATION', ha='center', va='center',
        fontsize=9, fontweight='bold', color=colors['validation_border'])

# Validation items in 2 columns
val_left = ['\u2022 Permutation Test (n=200)', '\u2022 Data Leakage Detection', '\u2022 Gap Nested CV']
val_right = ['\u2022 Ablation Study', '\u2022 Learning Curves', '\u2022 LOSO-CV']

for i, txt in enumerate(val_left):
    ax.text(6, 27 - i*2.8, txt, ha='left', va='center', fontsize=7, color='#424242')
for i, txt in enumerate(val_right):
    ax.text(28, 27 - i*2.8, txt, ha='left', va='center', fontsize=7, color='#424242')

# Explainability (SHAP)
draw_box(ax, 52, 18, 46, 13.5, colors['shap'], colors['shap_border'])
ax.text(75, 30, 'EXPLAINABILITY (SHAP)', ha='center', va='center',
        fontsize=9, fontweight='bold', color=colors['shap_border'])

shap_items = [
    '\u2022 Feature Importance Ranking',
    '\u2022 Top Biomarkers: COX8C, COX6A2,',
    '  COX7A1, COX4I2',
    '\u2022 Mitochondrial Dysfunction Signatures',
    '\u2022 Clinical Decision Support Potential'
]
for i, txt in enumerate(shap_items):
    ax.text(55, 27 - i*2.2, txt, ha='left', va='center', fontsize=7, color='#424242')

# Arrow from validation to explainability
draw_arrow(ax, 49, 24.5, 52, 24.5)

# ===== RESULT BOX (bottom) =====
draw_arrow(ax, 50, 18, 50, 15)

draw_box(ax, 20, 7, 60, 7, '#FFF9C4', '#F57F17')
ax.text(50, 12, 'BEST MODEL: Random Forest', ha='center', va='center',
        fontsize=9, fontweight='bold', color='#E65100')
ax.text(50, 10, 'AUC = 0.986 \u00b1 0.015 | No Overfitting Detected', ha='center', va='center',
        fontsize=7.5, color='#424242')
ax.text(50, 8.2, 'Permutation p = 0.005 | Train-Test Gap = 0.01', ha='center', va='center',
        fontsize=7.5, color='#424242')

# Save in journal-required formats
plt.tight_layout(pad=0.5)

# TIFF at 600 DPI (combination line/halftone requirement: min 500 dpi)
plt.savefig('/home/ubuntu/Figure_1.tiff', dpi=600, format='tiff',
            bbox_inches='tight', facecolor='white')

# PNG at 600 DPI (alternative accepted format)
plt.savefig('/home/ubuntu/Figure_1.png', dpi=600, format='png',
            bbox_inches='tight', facecolor='white')

plt.close()

print("Figure 1 saved successfully for Computers in Biology and Medicine!")
print("=" * 60)

# Verify dimensions
from PIL import Image
img = Image.open('/home/ubuntu/Figure_1.png')
w, h = img.size
print(f"Dimensions: {w} x {h} pixels")
print(f"At 600 DPI: {w/600*25.4:.1f}mm x {h/600*25.4:.1f}mm")
print(f"Full page width requirement (min 3740 px at 500 dpi): {'PASS' if w >= 3740 else 'FAIL'} ({w} px)")
print(f"DPI: 600 (requirement: min 500 for combination figures)")
print(f"Format: TIFF + PNG")
print(f"Color mode: RGB")
