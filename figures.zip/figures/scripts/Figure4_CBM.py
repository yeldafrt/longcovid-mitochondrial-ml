"""
Figure 4 - SHAP Feature Importance
Panels: (A) SHAP Bar Plot (Top 15), (B) SHAP Beeswarm Plot (Top 15)
Computers in Biology and Medicine (Elsevier) Guidelines:
- Combination bitmapped line/halftones: min 500 dpi
- Full page width: min 3740 pixels at 500 dpi
- Format: TIFF, JPG, PNG
- RGB color mode
- Using 600 DPI for safety margin
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

# Load data
shap_vals = np.load('/home/ubuntu/model_project/results/npy_arrays/shap_values.npy')
X = np.load('/home/ubuntu/model_project/results/npy_arrays/X_batch_corrected.npy')
shap_fi = pd.read_csv('/home/ubuntu/model_project/results/metrics/shap_feature_importance.csv')

feature_names = shap_fi['gene'].values
top_n = 15
top_genes = shap_fi.head(top_n)['gene'].values
top_idx = [list(feature_names).index(g) for g in top_genes]

fig, axes = plt.subplots(1, 2, figsize=(7.09, 4.0), dpi=600,
                          gridspec_kw={'width_ratios': [0.8, 1.2]})

# ===== Panel (A): SHAP Bar Plot =====
ax = axes[0]
importance_vals = shap_fi.head(top_n)['shap_importance'].values
colors = plt.cm.Blues(np.linspace(0.4, 0.9, top_n))[::-1]

y_pos = np.arange(top_n)
ax.barh(y_pos, importance_vals[::-1], color=colors, edgecolor='black', linewidth=0.5, height=0.7)
ax.set_yticks(y_pos)
ax.set_yticklabels(top_genes[::-1], fontsize=7, fontfamily='monospace')
ax.set_xlabel('Mean |SHAP Value|', fontsize=8)
ax.tick_params(labelsize=7)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.text(-0.15, 1.04, '(A)', transform=ax.transAxes, fontsize=11, fontweight='bold')

# ===== Panel (B): SHAP Beeswarm Plot =====
ax = axes[1]

# Get SHAP and feature values for top genes
shap_top = shap_vals[:, top_idx]
X_top = X[:, top_idx]

# Plot beeswarm
np.random.seed(42)  # For reproducibility
for i, gene_idx in enumerate(range(top_n)):
    shap_gene = shap_top[:, gene_idx]
    x_gene = X_top[:, gene_idx]
    
    # Normalize feature values for coloring
    norm = Normalize(vmin=np.percentile(x_gene, 5), vmax=np.percentile(x_gene, 95))
    colors_scatter = plt.cm.RdBu_r(norm(x_gene))
    
    # Add jitter
    y_jitter = (top_n - 1 - i) + np.random.uniform(-0.25, 0.25, len(shap_gene))
    
    ax.scatter(shap_gene, y_jitter, c=colors_scatter, s=3, alpha=0.5, linewidths=0)

ax.axvline(x=0, color='gray', linestyle='-', linewidth=0.5, alpha=0.5)
ax.set_yticks(np.arange(top_n))
ax.set_yticklabels(top_genes[::-1], fontsize=7, fontfamily='monospace')
ax.set_xlabel('SHAP Value (Impact on Model Output)', fontsize=8)
ax.tick_params(labelsize=7)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Colorbar
sm = ScalarMappable(cmap=plt.cm.RdBu_r, norm=Normalize(vmin=0, vmax=1))
sm.set_array([])
cbar = plt.colorbar(sm, ax=ax, shrink=0.5, aspect=20, pad=0.02)
cbar.set_ticks([0, 1])
cbar.set_ticklabels(['Low', 'High'], fontsize=7)
cbar.set_label('Feature Value', fontsize=7)

ax.text(-0.12, 1.04, '(B)', transform=ax.transAxes, fontsize=11, fontweight='bold')

plt.tight_layout(pad=1.5)

# Save in all formats at 600 DPI
plt.savefig('/home/ubuntu/Figure_4.tiff', dpi=600, format='tiff',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_4.png', dpi=600, format='png',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_4.jpg', dpi=600, format='jpeg',
            bbox_inches='tight', facecolor='white', pil_kwargs={'quality': 95})
plt.close()

# Convert RGBA to RGB if needed
from PIL import Image
import os

for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_4.{fmt}'
    img = Image.open(filepath)
    if img.mode == 'RGBA':
        rgb_img = Image.new('RGB', img.size, (255, 255, 255))
        rgb_img.paste(img, mask=img.split()[3])
        rgb_img.save(filepath, dpi=(600, 600), quality=95 if fmt == 'jpg' else None)
    elif img.mode != 'RGB':
        img.convert('RGB').save(filepath, dpi=(600, 600))

# Final verification
print("Figure 4 saved successfully for Computers in Biology and Medicine!")
print("=" * 60)
for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_4.{fmt}'
    img = Image.open(filepath)
    size_mb = os.path.getsize(filepath) / 1024 / 1024
    print(f"  {fmt.upper():4s} - {img.size[0]}x{img.size[1]} px, Mode: {img.mode}, "
          f"DPI: {img.info.get('dpi', 'N/A')}, Size: {size_mb:.1f} MB")

w = img.size[0]
print(f"\nFull page width requirement (min 3740 px at 500 dpi): {'PASS' if w >= 3740 else 'FAIL'} ({w} px)")
print(f"DPI: 600 (requirement: min 500 for combination figures)")
