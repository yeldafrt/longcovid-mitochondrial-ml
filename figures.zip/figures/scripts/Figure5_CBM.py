"""
Figure 5 - Biological Interpretation of SHAP Features
Panels: (A) SHAP by functional category, (B) Top 4 genes partial dependence, (C) Category pie chart
Computers in Biology and Medicine (Elsevier) Guidelines:
- Combination bitmapped line/halftones: min 500 dpi
- Full page width: min 3740 pixels at 500 dpi
- Format: TIFF, JPG, PNG
- RGB color mode
- Using 600 DPI for safety margin
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load data
shap_vals = np.load('/home/ubuntu/model_project/results/npy_arrays/shap_values.npy')
X = np.load('/home/ubuntu/model_project/results/npy_arrays/X_batch_corrected.npy')

# Get ORIGINAL feature order (matching shap_vals columns)
shap_df = pd.read_csv('/home/ubuntu/model_project/results/plot_data/shap_values_matrix.csv.gz', nrows=1)
original_features = shap_df.columns.tolist()

# SHAP importance from CSV (sorted)
shap_fi = pd.read_csv('/home/ubuntu/model_project/results/metrics/shap_feature_importance.csv')

# Define comprehensive gene-to-category mapping
gene_categories = {}
# Complex I
for g in ['NDUFA1','NDUFA2','NDUFA3','NDUFA4','NDUFA5','NDUFA6','NDUFA7','NDUFA8','NDUFA9','NDUFA10',
          'NDUFA11','NDUFA12','NDUFA13','NDUFAB1','NDUFB1','NDUFB2','NDUFB3','NDUFB4','NDUFB5',
          'NDUFB6','NDUFB7','NDUFB8','NDUFB9','NDUFB10','NDUFB11','NDUFC1','NDUFC2',
          'NDUFS1','NDUFS2','NDUFS3','NDUFS4','NDUFS5','NDUFS6','NDUFS7','NDUFS8',
          'NDUFV1','NDUFV2','NDUFV3','MT-ND1','MT-ND2','MT-ND3','MT-ND4','MT-ND4L','MT-ND5','MT-ND6']:
    gene_categories[g] = 'Complex I'
# Complex II
for g in ['SDHA','SDHB','SDHC','SDHD','SDHAF1','SDHAF2']:
    gene_categories[g] = 'Complex II'
# Complex III
for g in ['UQCRC1','UQCRC2','UQCRFS1','UQCRB','UQCRH','UQCRQ','CYC1','MT-CYB','BCS1L']:
    gene_categories[g] = 'Complex III'
# Complex IV
for g in ['COX4I1','COX4I2','COX5A','COX5B','COX6A1','COX6A2','COX6B1','COX6B2','COX6C',
          'COX7A1','COX7A2','COX7B','COX7C','COX8A','COX8C','COX10','COX11','COX14',
          'COX15','COX16','COX17','COX18','COX19','COX20','MT-CO1','MT-CO2','MT-CO3','CYCS']:
    gene_categories[g] = 'Complex IV'
# ATP Synthase
for g in ['ATP5F1A','ATP5F1B','ATP5F1C','ATP5F1D','ATP5F1E','ATP5MC1','ATP5MC2','ATP5MC3',
          'ATP5MF','ATP5MG','ATP5PB','ATP5PD','ATP5PF','ATP5PO','MT-ATP6','MT-ATP8']:
    gene_categories[g] = 'ATP Synthase'
# Biogenesis
for g in ['PPARGC1A','PPARGC1B','NRF1','TFAM','TFB1M','TFB2M']:
    gene_categories[g] = 'Biogenesis'
# Dynamics
for g in ['MFN1','MFN2','OPA1','FIS1','MFF','MIEF1']:
    gene_categories[g] = 'Dynamics'
# mtDNA maintenance
for g in ['POLG','POLG2','TWNK','LONP1','CLPP','HSPD1','HSPE1']:
    gene_categories[g] = 'mtDNA Maintenance'
# Stress Response
for g in ['HSPA9','ATF4','ATF5','DDIT3','RECQL4']:
    gene_categories[g] = 'Stress Response'
# ROS Defense
for g in ['SOD1','SOD2','CAT','GPX4','PRDX3','PRDX5','TXN2','TXNRD2']:
    gene_categories[g] = 'ROS Defense'
# Apoptosis
for g in ['BAX','BAK1','BCL2','BCL2L1','CYCS','APAF1','DIABLO']:
    gene_categories[g] = 'Apoptosis'
# Transport/Other
for g in ['VDAC1','VDAC2','VDAC3','PYCR1','TMPRSS2','MAVS','NLRP3','CASP1']:
    gene_categories[g] = 'Transport/Other'

# Compute category importance using CORRECT feature order
cat_importance = {}
for cat in set(gene_categories.values()):
    idx = [i for i, g in enumerate(original_features) if gene_categories.get(g, 'Unclassified') == cat]
    if idx:
        cat_importance[cat] = np.sum([np.mean(np.abs(shap_vals[:, i])) for i in idx])

cat_df = pd.DataFrame(list(cat_importance.items()), columns=['Category', 'Sum_SHAP'])
cat_df = cat_df.sort_values('Sum_SHAP', ascending=False)

# Top 20 genes with correct categories
top20_genes = shap_fi.head(20)['gene'].values
top20_cats = [gene_categories.get(g, 'Unclassified') for g in top20_genes]

fig, axes = plt.subplots(1, 3, figsize=(7.09, 3.5), dpi=600,
                          gridspec_kw={'width_ratios': [1, 1.2, 0.8]})

# ===== Panel (A): SHAP by functional category =====
ax = axes[0]
cat_colors = {
    'Complex IV': '#D32F2F', 'Complex I': '#1565C0', 'Complex II': '#FF8F00',
    'Complex III': '#00695C', 'ATP Synthase': '#2E7D32', 'Biogenesis': '#6A1B9A',
    'Dynamics': '#00838F', 'ROS Defense': '#E65100', 'Apoptosis': '#4E342E',
    'Stress Response': '#37474F', 'Transport/Other': '#546E7A',
    'mtDNA Maintenance': '#795548', 'Unclassified': '#BDBDBD'
}

y_pos = np.arange(len(cat_df))
colors = [cat_colors.get(c, '#BDBDBD') for c in cat_df['Category']]
ax.barh(y_pos, cat_df['Sum_SHAP'].values, color=colors, edgecolor='black', linewidth=0.5, height=0.65)
ax.set_yticks(y_pos)
ax.set_yticklabels(cat_df['Category'].values, fontsize=6.5)
ax.set_xlabel('Cumulative |SHAP| Contribution', fontsize=7)
ax.tick_params(labelsize=6.5)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.text(-0.18, 1.04, '(A)', transform=ax.transAxes, fontsize=11, fontweight='bold')

# ===== Panel (B): Partial Dependence for Top 4 genes =====
ax = axes[1]
top4_genes = ['COX8C', 'COX6A2', 'COX7A1', 'COX4I2']
top4_colors = ['#D32F2F', '#E53935', '#EF5350', '#F44336']
top4_linestyles = ['-', '--', '-.', ':']

for i, gene in enumerate(top4_genes):
    gene_idx = original_features.index(gene)  # CORRECT index
    x_vals = X[:, gene_idx]
    shap_gene = shap_vals[:, gene_idx]
    
    # Sort by feature value for smooth line
    sort_idx = np.argsort(x_vals)
    x_sorted = x_vals[sort_idx]
    shap_sorted = shap_gene[sort_idx]
    
    # Moving average for smoothing
    window = 25
    if len(x_sorted) > window:
        x_smooth = np.convolve(x_sorted, np.ones(window)/window, mode='valid')
        shap_smooth = np.convolve(shap_sorted, np.ones(window)/window, mode='valid')
    else:
        x_smooth = x_sorted
        shap_smooth = shap_sorted
    
    ax.plot(x_smooth, shap_smooth, color=top4_colors[i], linewidth=1.8, 
            label=gene, alpha=0.9, linestyle=top4_linestyles[i])
    ax.scatter(x_vals, shap_gene, color=top4_colors[i], s=2, alpha=0.1)

ax.axhline(y=0, color='gray', linestyle='--', linewidth=0.5, alpha=0.5)
ax.set_xlabel('Gene Expression (Z-score)', fontsize=7)
ax.set_ylabel('SHAP Value', fontsize=7)
ax.legend(fontsize=6.5, loc='lower left', framealpha=0.9)
ax.tick_params(labelsize=6.5)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.text(-0.12, 1.04, '(B)', transform=ax.transAxes, fontsize=11, fontweight='bold')

# ===== Panel (C): Category distribution of Top 20 genes =====
ax = axes[2]
cat_counts = pd.Series(top20_cats).value_counts()
pie_colors = [cat_colors.get(c, '#BDBDBD') for c in cat_counts.index]

wedges, texts, autotexts = ax.pie(cat_counts.values, labels=None, autopct='%1.0f%%',
                                   colors=pie_colors, startangle=90,
                                   textprops={'fontsize': 6},
                                   pctdistance=0.8)
for autotext in autotexts:
    autotext.set_fontsize(6)

ax.legend(cat_counts.index, fontsize=5.5, loc='center left', bbox_to_anchor=(-0.3, -0.25), ncol=2)
ax.text(-0.1, 1.04, '(C)', transform=ax.transAxes, fontsize=11, fontweight='bold')

plt.tight_layout(pad=1.0)

# Save in all formats at 600 DPI
plt.savefig('/home/ubuntu/Figure_5.tiff', dpi=600, format='tiff',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_5.png', dpi=600, format='png',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_5.jpg', dpi=600, format='jpeg',
            bbox_inches='tight', facecolor='white', pil_kwargs={'quality': 95})
plt.close()

# Convert RGBA to RGB if needed
from PIL import Image
import os

for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_5.{fmt}'
    img = Image.open(filepath)
    if img.mode == 'RGBA':
        rgb_img = Image.new('RGB', img.size, (255, 255, 255))
        rgb_img.paste(img, mask=img.split()[3])
        rgb_img.save(filepath, dpi=(600, 600), quality=95 if fmt == 'jpg' else None)
    elif img.mode != 'RGB':
        img.convert('RGB').save(filepath, dpi=(600, 600))

# Final verification
print("Figure 5 saved successfully for Computers in Biology and Medicine!")
print("=" * 60)
for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_5.{fmt}'
    img = Image.open(filepath)
    size_mb = os.path.getsize(filepath) / 1024 / 1024
    print(f"  {fmt.upper():4s} - {img.size[0]}x{img.size[1]} px, Mode: {img.mode}, "
          f"DPI: {img.info.get('dpi', 'N/A')}, Size: {size_mb:.1f} MB")

w = img.size[0]
print(f"\nFull page width requirement (min 3740 px at 500 dpi): {'PASS' if w >= 3740 else 'FAIL'} ({w} px)")
print(f"DPI: 600 (requirement: min 500 for combination figures)")

print(f"\nCategory importance (sorted):")
for _, row in cat_df.iterrows():
    print(f"  {row['Category']}: {row['Sum_SHAP']:.4f}")
