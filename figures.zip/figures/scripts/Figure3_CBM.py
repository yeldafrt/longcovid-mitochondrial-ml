"""
Figure 3 - LOSO-CV Results and Dataset Class Distribution
Computers in Biology and Medicine (Elsevier) Guidelines:
- Combination bitmapped line/halftones: min 500 dpi
- Full page width: min 3740 pixels at 500 dpi
- Format: TIFF, JPG, PNG
- RGB color mode
- Using 600 DPI for safety margin
"""

import matplotlib.pyplot as plt
import numpy as np

# Data
datasets = ['GSE152418', 'GSE169687', 'GSE222253', 'GSE235938', 'GSE265753', 'GSE267625']
n_class0 = [34, 142, 0, 1, 2, 0]
n_class1 = [0, 0, 35, 2, 16, 111]
has_both = ['No', 'No', 'No', 'Yes', 'Yes', 'No']

# LOSO results (only for datasets with both classes)
loso_datasets = ['GSE235938\n(n=3)', 'GSE265753\n(n=18)']
loso_rf = [1.0, 0.594]
loso_xgb = [0.0, 0.5]
loso_gb = [0.5, 0.219]
loso_svm = [0.5, 0.375]

fig, axes = plt.subplots(1, 2, figsize=(7.09, 3.0), dpi=600, 
                          gridspec_kw={'width_ratios': [1.3, 1]})

# ===== Panel (A): Dataset class composition =====
ax = axes[0]
x = np.arange(len(datasets))
width = 0.35

bars1 = ax.bar(x - width/2, n_class0, width, label='Recovered/Healthy (Class 0)', 
               color='#4CAF50', edgecolor='black', linewidth=0.5)
bars2 = ax.bar(x + width/2, n_class1, width, label='Persistent (Class 1)', 
               color='#F44336', edgecolor='black', linewidth=0.5)

# Mark datasets with both classes
for i, both in enumerate(has_both):
    if both == 'Yes':
        ax.annotate('*', xy=(x[i], max(n_class0[i], n_class1[i]) + 5),
                   fontsize=14, ha='center', fontweight='bold', color='#1565C0')

ax.set_xlabel('Dataset', fontsize=8)
ax.set_ylabel('Number of Samples', fontsize=8)
ax.set_xticks(x)
ax.set_xticklabels(datasets, fontsize=7, rotation=15, ha='right')
ax.tick_params(labelsize=7)
ax.legend(fontsize=6.5, loc='upper left')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# Add annotation
ax.text(0.98, 0.95, '* Both classes present\n(eligible for LOSO test)', 
        transform=ax.transAxes, fontsize=6, ha='right', va='top',
        color='#1565C0', style='italic')

ax.text(-0.12, 1.08, '(A)', transform=ax.transAxes, fontsize=10, fontweight='bold')

# ===== Panel (B): LOSO-CV AUC results =====
ax = axes[1]
x = np.arange(len(loso_datasets))
width = 0.18

bars_rf = ax.bar(x - 1.5*width, loso_rf, width, label='RF', color='#1565C0', edgecolor='black', linewidth=0.5)
bars_xgb = ax.bar(x - 0.5*width, loso_xgb, width, label='XGBoost', color='#2E7D32', edgecolor='black', linewidth=0.5)
bars_gb = ax.bar(x + 0.5*width, loso_gb, width, label='GB', color='#E65100', edgecolor='black', linewidth=0.5)
bars_svm = ax.bar(x + 1.5*width, loso_svm, width, label='SVM', color='#6A1B9A', edgecolor='black', linewidth=0.5)

# Random baseline line
ax.axhline(y=0.5, color='gray', linestyle='--', linewidth=1, alpha=0.7, label='Random (0.5)')

ax.set_xlabel('Test Dataset (Left-Out Study)', fontsize=8)
ax.set_ylabel('AUC', fontsize=8)
ax.set_xticks(x)
ax.set_xticklabels(loso_datasets, fontsize=7)
ax.tick_params(labelsize=7)
ax.set_ylim([0, 1.15])
ax.legend(fontsize=6, loc='upper right', ncol=2)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

ax.text(-0.12, 1.08, '(B)', transform=ax.transAxes, fontsize=10, fontweight='bold')

plt.tight_layout(pad=1.2)

# Save in all formats at 600 DPI
plt.savefig('/home/ubuntu/Figure_3.tiff', dpi=600, format='tiff',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_3.png', dpi=600, format='png',
            bbox_inches='tight', facecolor='white')
plt.savefig('/home/ubuntu/Figure_3.jpg', dpi=600, format='jpeg',
            bbox_inches='tight', facecolor='white', pil_kwargs={'quality': 95})
plt.close()

# Convert RGBA to RGB if needed
from PIL import Image
import os

for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_3.{fmt}'
    img = Image.open(filepath)
    if img.mode == 'RGBA':
        rgb_img = Image.new('RGB', img.size, (255, 255, 255))
        rgb_img.paste(img, mask=img.split()[3])
        rgb_img.save(filepath, dpi=(600, 600), quality=95 if fmt == 'jpg' else None)
    elif img.mode != 'RGB':
        img.convert('RGB').save(filepath, dpi=(600, 600))

# Final verification
print("Figure 3 saved successfully for Computers in Biology and Medicine!")
print("=" * 60)
for fmt in ['tiff', 'png', 'jpg']:
    filepath = f'/home/ubuntu/Figure_3.{fmt}'
    img = Image.open(filepath)
    size_mb = os.path.getsize(filepath) / 1024 / 1024
    print(f"  {fmt.upper():4s} - {img.size[0]}x{img.size[1]} px, Mode: {img.mode}, "
          f"DPI: {img.info.get('dpi', 'N/A')}, Size: {size_mb:.1f} MB")

w = img.size[0]
print(f"\nFull page width requirement (min 3740 px at 500 dpi): {'PASS' if w >= 3740 else 'FAIL'} ({w} px)")
print(f"DPI: 600 (requirement: min 500 for combination figures)")
