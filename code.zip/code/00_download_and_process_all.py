#!/usr/bin/env python3
"""
00_download_and_process_all.py
Master script: Downloads all GEO datasets, processes them, converts scRNA-seq
to pseudobulk, merges everything, and prepares for binary classification.

IMPORTANT: This script requires significant time and disk space.
  - GSE265753: ~500MB download, ~30 min processing
  - GSE235938: ~260MB download
  - Total disk: ~2GB needed

Dependencies:
  pip install pandas numpy scipy requests gzip

Usage:
  python 00_download_and_process_all.py
"""
import os
import sys
import subprocess

print("""
╔══════════════════════════════════════════════════════════════╗
║  LONG COVID MITOCHONDRIAL DYSFUNCTION STUDY                  ║
║  Data Download & Processing Pipeline                         ║
╠══════════════════════════════════════════════════════════════╣
║  Datasets:                                                   ║
║    1. GSE152418 - Acute COVID-19 (34 samples, bulk RNA-seq)  ║
║    2. GSE267625 - Long COVID longitudinal (111 samples)      ║
║    3. GSE169687 - Post-COVID recovery (142 samples)          ║
║    4. GSE222253 - Post-COVID endotypes (35 samples)          ║
║    5. GSE265753 - Long COVID scRNA-seq (18 patients)         ║
║    6. GSE235938 - PASC myeloid scRNA-seq (3 libraries)       ║
╚══════════════════════════════════════════════════════════════╝
""")

# This script provides the download URLs and processing steps.
# Due to file sizes, actual downloads should be done separately.

DOWNLOAD_URLS = {
    'GSE152418': {
        'series_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE152nnn/GSE152418/matrix/GSE152418_series_matrix.txt.gz',
        'counts': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE152nnn/GSE152418/suppl/GSE152418_p20047_Study1_RawCounts.txt.gz'
    },
    'GSE267625': {
        'series_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE267nnn/GSE267625/matrix/GSE267625_series_matrix.txt.gz',
        'counts': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE267nnn/GSE267625/suppl/GSE267625_blood_transcriptome_raw_counts.csv.gz'
    },
    'GSE169687': {
        'series_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE169nnn/GSE169687/matrix/GSE169687_series_matrix.txt.gz',
        'note': 'Individual sample files - see download_gse169687.py'
    },
    'GSE222253': {
        'series_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE222nnn/GSE222253/matrix/GSE222253_series_matrix.txt.gz',
        'raw_tar': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE222nnn/GSE222253/suppl/GSE222253_RAW.tar'
    },
    'GSE265753': {
        'counts_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE265nnn/GSE265753/suppl/GSE265753_processed_counts_matrix.csv.gz',
        'note': '506MB - scRNA-seq processed counts (239K cells x 29K genes)'
    },
    'GSE235938': {
        'PASC1_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512191/suppl/GSM7512191_PASC1_matrix.mtx.gz',
        'PASC1_barcodes': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512191/suppl/GSM7512191_PASC1_barcodes.tsv.gz',
        'PASC1_features': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512191/suppl/GSM7512191_PASC1_features.tsv.gz',
        'PASC2_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512192/suppl/GSM7512192_PASC2_matrix.mtx.gz',
        'PASC2_barcodes': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512192/suppl/GSM7512192_PASC2_barcodes.tsv.gz',
        'PASC2_features': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512192/suppl/GSM7512192_PASC2_features.tsv.gz',
        'ctrl2_matrix': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512193/suppl/GSM7512193_ctrl2_matrix.mtx.gz',
        'ctrl2_barcodes': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512193/suppl/GSM7512193_ctrl2_barcodes.tsv.gz',
        'ctrl2_features': 'https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM7512nnn/GSM7512193/suppl/GSM7512193_ctrl2_features.tsv.gz',
    }
}

print("Download URLs for all datasets:")
print("=" * 60)
for dataset, urls in DOWNLOAD_URLS.items():
    print(f"\n{dataset}:")
    for key, url in urls.items():
        print(f"  {key}: {url}")

print("""
\n
PROCESSING PIPELINE:
====================
Step 1: Run this script to see download URLs
Step 2: Download files (wget/curl) - see download_scrna_datasets.sh
Step 3: Run 01_prepare_binary_dataset.py (requires pre-processed merged data)
Step 4: Run 02_train_model.py
Step 5: Run 03_differential_expression.py
Step 6: Run 04_visualization.py

For the pre-processed merged data, use the provided zip file:
  longcovid_FINAL_343samples_model_ready.zip
""")
