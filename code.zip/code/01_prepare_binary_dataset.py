#!/usr/bin/env python3
"""
01_prepare_binary_dataset.py
Prepare the merged dataset for binary classification:
  - Class 1 (Persistent): Long_COVID + Long_COVID_PASC + Post_COVID_Endotype
  - Class 0 (Recovered/Healthy): Post_COVID_Recovery + Healthy_Control + Acute_COVID

This creates a balanced binary classification problem (~164 vs ~179 samples).
"""
import pandas as pd
import numpy as np
import os

# Paths
INPUT_DIR = "final_merged"  # or wherever your FINAL files are
OUTPUT_DIR = "binary_model_ready"
os.makedirs(OUTPUT_DIR, exist_ok=True)

print("=" * 60)
print("BINARY CLASSIFICATION DATASET PREPARATION")
print("=" * 60)

# Load data
print("\n[1/4] Loading merged data...")
raw_counts = pd.read_csv(os.path.join(INPUT_DIR, "FINAL_merged_raw_counts.csv.gz"),
                         compression='gzip', index_col=0)
log2cpm = pd.read_csv(os.path.join(INPUT_DIR, "FINAL_merged_log2cpm.csv.gz"),
                      compression='gzip', index_col=0)
metadata = pd.read_csv(os.path.join(INPUT_DIR, "FINAL_unified_metadata.csv"))
mito_genes = pd.read_csv(os.path.join(INPUT_DIR, "mitochondrial_gene_sets.csv"))

print(f"  Raw counts: {raw_counts.shape}")
print(f"  Log2CPM: {log2cpm.shape}")
print(f"  Metadata: {metadata.shape}")
print(f"  Mitochondrial genes: {len(mito_genes)}")

# Binary label mapping
print("\n[2/4] Creating binary labels...")
binary_map = {
    'Long_COVID': 'Persistent',
    'Long_COVID_PASC': 'Persistent',
    'Post_COVID_Endotype': 'Persistent',
    'Post_COVID_Recovery': 'Recovered_Healthy',
    'Healthy_Control': 'Recovered_Healthy',
    'Acute_COVID': 'Recovered_Healthy'
}

metadata['binary_label'] = metadata['condition'].map(binary_map)
metadata['binary_numeric'] = (metadata['binary_label'] == 'Persistent').astype(int)

print(f"\n  Binary distribution:")
print(f"    Persistent (Long COVID): {(metadata['binary_label'] == 'Persistent').sum()}")
print(f"    Recovered/Healthy: {(metadata['binary_label'] == 'Recovered_Healthy').sum()}")
print(f"    Balance ratio: {(metadata['binary_label'] == 'Persistent').sum() / len(metadata):.2%}")

# Filter mitochondrial genes
print("\n[3/4] Filtering mitochondrial genes...")
mito_gene_list = mito_genes['gene_symbol'].tolist()
mito_in_data = [g for g in mito_gene_list if g in log2cpm.index]
print(f"  Mitochondrial genes in dataset: {len(mito_in_data)} / {len(mito_gene_list)}")

# Create mitochondrial-only matrix
log2cpm_mito = log2cpm.loc[mito_in_data]
raw_counts_mito = raw_counts.loc[mito_in_data]
print(f"  Mito-filtered matrix: {log2cpm_mito.shape}")

# Save
print("\n[4/4] Saving binary classification dataset...")

# Full gene set (for full transcriptome analysis)
log2cpm.to_csv(os.path.join(OUTPUT_DIR, "X_full_transcriptome_log2cpm.csv.gz"), compression='gzip')
raw_counts.to_csv(os.path.join(OUTPUT_DIR, "X_full_transcriptome_raw.csv.gz"), compression='gzip')

# Mitochondrial gene set only (for focused analysis)
log2cpm_mito.to_csv(os.path.join(OUTPUT_DIR, "X_mito_genes_log2cpm.csv.gz"), compression='gzip')
raw_counts_mito.to_csv(os.path.join(OUTPUT_DIR, "X_mito_genes_raw.csv.gz"), compression='gzip')

# Metadata with binary labels
metadata.to_csv(os.path.join(OUTPUT_DIR, "y_metadata_binary.csv"), index=False)

# Mitochondrial gene info
mito_genes_filtered = mito_genes[mito_genes['gene_symbol'].isin(mito_in_data)]
mito_genes_filtered.to_csv(os.path.join(OUTPUT_DIR, "mitochondrial_genes_in_dataset.csv"), index=False)

# Summary
summary = f"""BINARY CLASSIFICATION DATASET
{'='*50}

Task: Predict Long COVID Persistence vs. Recovery
  Class 1 (Persistent): Long_COVID + Long_COVID_PASC + Post_COVID_Endotype = {(metadata['binary_label'] == 'Persistent').sum()} samples
  Class 0 (Recovered/Healthy): Post_COVID_Recovery + Healthy_Control + Acute_COVID = {(metadata['binary_label'] == 'Recovered_Healthy').sum()} samples

Data:
  Full transcriptome: {log2cpm.shape[0]} genes x {log2cpm.shape[1]} samples
  Mitochondrial only: {log2cpm_mito.shape[0]} genes x {log2cpm_mito.shape[1]} samples

Files:
  X_full_transcriptome_log2cpm.csv.gz  - Full gene expression (model input option 1)
  X_mito_genes_log2cpm.csv.gz          - Mito genes only (model input option 2)
  X_full_transcriptome_raw.csv.gz      - Raw counts (for DESeq2/edgeR)
  X_mito_genes_raw.csv.gz              - Raw mito counts
  y_metadata_binary.csv                - Labels (binary_label, binary_numeric columns)
  mitochondrial_genes_in_dataset.csv   - Mito gene annotations

Recommended approach:
  1. Use X_mito_genes_log2cpm.csv.gz as primary model input
  2. Use binary_numeric column from y_metadata_binary.csv as target
  3. Use batch column for batch effect correction
  4. Use dataset column for Leave-One-Study-Out cross-validation
"""

with open(os.path.join(OUTPUT_DIR, "DATASET_INFO.txt"), 'w') as f:
    f.write(summary)

print(summary)
print(f"\nOutput directory: {OUTPUT_DIR}")
print("DONE!")
