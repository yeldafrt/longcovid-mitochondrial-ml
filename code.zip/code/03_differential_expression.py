#!/usr/bin/env python3
"""
03_differential_expression.py
Differential expression analysis for mitochondrial genes between
Long COVID Persistent vs. Recovered/Healthy groups.
Includes:
  - Wilcoxon rank-sum test
  - Fold change calculation
  - Multiple testing correction (Benjamini-Hochberg)
  - Volcano plot data
"""
import pandas as pd
import numpy as np
from scipy.stats import mannwhitneyu
from statsmodels.stats.multitest import multipletests
import os

DATA_DIR = "binary_model_ready"
RESULTS_DIR = "de_results"
os.makedirs(RESULTS_DIR, exist_ok=True)

print("=" * 60)
print("DIFFERENTIAL EXPRESSION ANALYSIS")
print("=" * 60)

# Load data
print("\n[1/3] Loading data...")
log2cpm = pd.read_csv(os.path.join(DATA_DIR, "X_mito_genes_log2cpm.csv.gz"),
                      compression='gzip', index_col=0)
metadata = pd.read_csv(os.path.join(DATA_DIR, "y_metadata_binary.csv"))

# Separate groups
persistent_samples = metadata[metadata['binary_label'] == 'Persistent']['sample_id'].tolist()
recovered_samples = metadata[metadata['binary_label'] == 'Recovered_Healthy']['sample_id'].tolist()

X_persistent = log2cpm[[s for s in persistent_samples if s in log2cpm.columns]]
X_recovered = log2cpm[[s for s in recovered_samples if s in log2cpm.columns]]

print(f"  Persistent: {X_persistent.shape[1]} samples")
print(f"  Recovered/Healthy: {X_recovered.shape[1]} samples")
print(f"  Genes: {log2cpm.shape[0]}")

# Differential expression
print("\n[2/3] Running differential expression...")
results = []
for gene in log2cpm.index:
    vals_p = X_persistent.loc[gene].values
    vals_r = X_recovered.loc[gene].values
    
    # Wilcoxon rank-sum test
    stat, pval = mannwhitneyu(vals_p, vals_r, alternative='two-sided')
    
    # Log2 fold change
    mean_p = vals_p.mean()
    mean_r = vals_r.mean()
    log2fc = mean_p - mean_r  # Already in log2 space
    
    results.append({
        'gene': gene,
        'mean_persistent': mean_p,
        'mean_recovered': mean_r,
        'log2FC': log2fc,
        'pvalue': pval,
        'statistic': stat
    })

de_df = pd.DataFrame(results)

# Multiple testing correction
de_df['padj'] = multipletests(de_df['pvalue'], method='fdr_bh')[1]
de_df['neg_log10_padj'] = -np.log10(de_df['padj'] + 1e-300)

# Significance classification
de_df['significance'] = 'Not Significant'
de_df.loc[(de_df['padj'] < 0.05) & (de_df['log2FC'] > 0.5), 'significance'] = 'Up in Persistent'
de_df.loc[(de_df['padj'] < 0.05) & (de_df['log2FC'] < -0.5), 'significance'] = 'Down in Persistent'

# Sort by significance
de_df = de_df.sort_values('pvalue')

print(f"\n  Significant genes (padj < 0.05):")
print(f"    Up in Persistent: {(de_df['significance'] == 'Up in Persistent').sum()}")
print(f"    Down in Persistent: {(de_df['significance'] == 'Down in Persistent').sum()}")
print(f"    Not significant: {(de_df['significance'] == 'Not Significant').sum()}")

# Save
print("\n[3/3] Saving results...")
de_df.to_csv(os.path.join(RESULTS_DIR, "DE_results_mito_genes.csv"), index=False)

# Top genes
top_up = de_df[de_df['significance'] == 'Up in Persistent'].head(20)
top_down = de_df[de_df['significance'] == 'Down in Persistent'].head(20)

print(f"\n  Top upregulated in Persistent (Long COVID):")
if len(top_up) > 0:
    print(top_up[['gene', 'log2FC', 'padj']].to_string(index=False))
else:
    print("    None found with current thresholds")

print(f"\n  Top downregulated in Persistent (Long COVID):")
if len(top_down) > 0:
    print(top_down[['gene', 'log2FC', 'padj']].to_string(index=False))
else:
    print("    None found with current thresholds")

print(f"\nResults saved to: {RESULTS_DIR}/DE_results_mito_genes.csv")
print("DONE!")
