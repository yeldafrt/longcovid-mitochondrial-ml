#!/usr/bin/env python3
"""
04_visualization.py
Generate publication-quality figures for the Long COVID study.
Includes:
  - PCA/UMAP of samples colored by condition
  - Volcano plot of DE genes
  - Heatmap of top mitochondrial genes
  - ROC curves for model comparison
  - SHAP summary plot
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import os

DATA_DIR = "binary_model_ready"
RESULTS_DIR = "figures"
os.makedirs(RESULTS_DIR, exist_ok=True)

# Set publication style
plt.rcParams.update({
    'font.size': 12,
    'font.family': 'sans-serif',
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight'
})

print("=" * 60)
print("GENERATING PUBLICATION FIGURES")
print("=" * 60)

# Load data
print("\n[1/5] Loading data...")
log2cpm = pd.read_csv(os.path.join(DATA_DIR, "X_mito_genes_log2cpm.csv.gz"),
                      compression='gzip', index_col=0)
metadata = pd.read_csv(os.path.join(DATA_DIR, "y_metadata_binary.csv"))

X = log2cpm.T  # samples x genes
print(f"  Data: {X.shape}")

# ============ Figure 1: PCA ============
print("\n[2/5] PCA plot...")
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Color by binary label
colors_binary = {'Persistent': '#e74c3c', 'Recovered_Healthy': '#2ecc71'}
for label, color in colors_binary.items():
    mask = metadata['binary_label'] == label
    axes[0].scatter(X_pca[mask, 0], X_pca[mask, 1], c=color, label=label, 
                    alpha=0.7, s=50, edgecolors='white', linewidth=0.5)
axes[0].set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)')
axes[0].set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)')
axes[0].set_title('PCA - Binary Classification')
axes[0].legend()

# Color by dataset (batch)
datasets = metadata['dataset'].unique()
cmap = plt.cm.get_cmap('tab10', len(datasets))
for i, ds in enumerate(datasets):
    mask = metadata['dataset'] == ds
    axes[1].scatter(X_pca[mask, 0], X_pca[mask, 1], c=[cmap(i)], label=ds,
                    alpha=0.7, s=50, edgecolors='white', linewidth=0.5)
axes[1].set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)')
axes[1].set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)')
axes[1].set_title('PCA - By Dataset (Batch)')
axes[1].legend(fontsize=8)

plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR, "Fig1_PCA.png"))
plt.close()
print("  Saved: Fig1_PCA.png")

# ============ Figure 2: Heatmap of top genes ============
print("\n[3/5] Heatmap...")
# Select top variable genes
gene_var = log2cpm.var(axis=1).sort_values(ascending=False)
top_genes = gene_var.head(30).index

heatmap_data = log2cpm.loc[top_genes]

# Create annotation for columns
col_colors = metadata['binary_label'].map(colors_binary).values

fig, ax = plt.subplots(figsize=(16, 10))
sns.heatmap(heatmap_data, cmap='RdBu_r', center=0, 
            xticklabels=False, yticklabels=True, ax=ax,
            cbar_kws={'label': 'Log2(CPM+1)'})
ax.set_title('Top 30 Variable Mitochondrial Genes')
ax.set_ylabel('Genes')
ax.set_xlabel(f'Samples (n={heatmap_data.shape[1]})')
plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR, "Fig2_Heatmap.png"))
plt.close()
print("  Saved: Fig2_Heatmap.png")

# ============ Figure 3: Sample distribution ============
print("\n[4/5] Sample distribution plot...")
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Binary distribution
binary_counts = metadata['binary_label'].value_counts()
axes[0].bar(binary_counts.index, binary_counts.values, 
            color=['#e74c3c', '#2ecc71'])
axes[0].set_title('Binary Classification Distribution')
axes[0].set_ylabel('Number of Samples')
for i, v in enumerate(binary_counts.values):
    axes[0].text(i, v + 2, str(v), ha='center', fontweight='bold')

# Dataset distribution
ds_counts = metadata['dataset'].value_counts()
axes[1].barh(ds_counts.index, ds_counts.values, color=plt.cm.Set3(np.linspace(0, 1, len(ds_counts))))
axes[1].set_title('Samples per Dataset')
axes[1].set_xlabel('Number of Samples')
for i, v in enumerate(ds_counts.values):
    axes[1].text(v + 1, i, str(v), va='center')

plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR, "Fig3_Distribution.png"))
plt.close()
print("  Saved: Fig3_Distribution.png")

# ============ Figure 4: Mitochondrial gene category distribution ============
print("\n[5/5] Mito gene categories...")
mito_info = pd.read_csv(os.path.join(DATA_DIR, "mitochondrial_genes_in_dataset.csv"))

if 'category' in mito_info.columns:
    cat_counts = mito_info['category'].value_counts()
    fig, ax = plt.subplots(figsize=(10, 6))
    cat_counts.plot(kind='barh', ax=ax, color=plt.cm.viridis(np.linspace(0, 1, len(cat_counts))))
    ax.set_title('Mitochondrial Gene Categories in Dataset')
    ax.set_xlabel('Number of Genes')
    plt.tight_layout()
    plt.savefig(os.path.join(RESULTS_DIR, "Fig4_Mito_Categories.png"))
    plt.close()
    print("  Saved: Fig4_Mito_Categories.png")
else:
    print("  Skipped: No category column in mito gene file")

print(f"\nAll figures saved to: {RESULTS_DIR}/")
print("DONE!")
