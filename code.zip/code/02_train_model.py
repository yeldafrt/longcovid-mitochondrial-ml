#!/usr/bin/env python3
"""
02_train_model.py
Train ML models for Long COVID persistence prediction using mitochondrial genes.
Includes:
  - Batch effect correction (ComBat)
  - Feature selection (differential expression + variance filtering)
  - Multiple classifiers (XGBoost, Random Forest, SVM, Logistic Regression)
  - Leave-One-Study-Out Cross-Validation
  - Stratified K-Fold Cross-Validation
  - SHAP explainability
  - Performance metrics (AUC, F1, Accuracy, Sensitivity, Specificity)
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold, LeaveOneGroupOut
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (roc_auc_score, f1_score, accuracy_score, 
                             classification_report, confusion_matrix, roc_curve)
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings('ignore')

# Optional imports (install if needed)
try:
    from xgboost import XGBClassifier
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False
    print("XGBoost not installed. Install with: pip install xgboost")

try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False
    print("SHAP not installed. Install with: pip install shap")

import os

# Paths
DATA_DIR = "binary_model_ready"
RESULTS_DIR = "model_results"
os.makedirs(RESULTS_DIR, exist_ok=True)

print("=" * 60)
print("MODEL TRAINING: Long COVID Persistence Prediction")
print("=" * 60)

# ============ 1. Load Data ============
print("\n[1/6] Loading data...")
X = pd.read_csv(os.path.join(DATA_DIR, "X_mito_genes_log2cpm.csv.gz"), 
                compression='gzip', index_col=0).T  # Transpose: samples x genes
metadata = pd.read_csv(os.path.join(DATA_DIR, "y_metadata_binary.csv"))

y = metadata['binary_numeric'].values
groups = metadata['dataset'].values  # For LOSO CV
batch = metadata['batch'].values

print(f"  X shape: {X.shape} (samples x genes)")
print(f"  y distribution: Persistent={y.sum()}, Recovered={len(y)-y.sum()}")
print(f"  Datasets: {metadata['dataset'].unique().tolist()}")

# ============ 2. Batch Effect Correction ============
print("\n[2/6] Batch effect correction...")
# Simple approach: standardize within each batch, then combine
# For more sophisticated correction, use pycombat
X_corrected = X.copy()
for b in np.unique(batch):
    mask = batch == b
    scaler = StandardScaler()
    X_corrected.iloc[mask] = scaler.fit_transform(X.iloc[mask])

print(f"  Batch-corrected matrix: {X_corrected.shape}")

# ============ 3. Feature Selection ============
print("\n[3/6] Feature selection...")
# Method 1: Variance filtering (remove low-variance genes)
variances = X_corrected.var(axis=0)
high_var_genes = variances[variances > variances.quantile(0.25)].index
X_filtered = X_corrected[high_var_genes]
print(f"  After variance filter: {X_filtered.shape[1]} genes")

# Method 2: T-test based selection
from scipy.stats import ttest_ind
pvalues = []
for gene in X_filtered.columns:
    stat, pval = ttest_ind(X_filtered[gene][y == 1], X_filtered[gene][y == 0])
    pvalues.append(pval)

pval_series = pd.Series(pvalues, index=X_filtered.columns)
significant_genes = pval_series[pval_series < 0.05].index
print(f"  Significant genes (p<0.05): {len(significant_genes)}")

# Use top genes if too many, or all significant if reasonable
if len(significant_genes) > 50:
    top_genes = pval_series.nsmallest(50).index
elif len(significant_genes) < 10:
    top_genes = pval_series.nsmallest(30).index  # Use top 30 anyway
else:
    top_genes = significant_genes

X_final = X_filtered[top_genes]
print(f"  Final feature set: {X_final.shape[1]} genes")

# Save selected genes
pd.DataFrame({'gene': top_genes, 'pvalue': pval_series[top_genes]}).to_csv(
    os.path.join(RESULTS_DIR, "selected_genes.csv"), index=False)

# ============ 4. Model Training with Cross-Validation ============
print("\n[4/6] Training models...")

# Define classifiers
classifiers = {
    'Random_Forest': RandomForestClassifier(n_estimators=200, random_state=42, 
                                             class_weight='balanced'),
    'Gradient_Boosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
    'SVM_RBF': SVC(kernel='rbf', probability=True, class_weight='balanced', random_state=42),
    'Logistic_Regression': LogisticRegression(max_iter=1000, class_weight='balanced', 
                                               random_state=42, penalty='l1', solver='saga'),
}

if HAS_XGBOOST:
    classifiers['XGBoost'] = XGBClassifier(
        n_estimators=200, max_depth=4, learning_rate=0.1,
        scale_pos_weight=(len(y) - y.sum()) / y.sum(),
        random_state=42, eval_metric='logloss', verbosity=0
    )

# A) Stratified 5-Fold CV
print("\n  --- Stratified 5-Fold Cross-Validation ---")
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

results_skf = {}
for name, clf in classifiers.items():
    aucs, f1s, accs = [], [], []
    for train_idx, test_idx in skf.split(X_final, y):
        X_train, X_test = X_final.iloc[train_idx], X_final.iloc[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        y_prob = clf.predict_proba(X_test)[:, 1]
        
        aucs.append(roc_auc_score(y_test, y_prob))
        f1s.append(f1_score(y_test, y_pred))
        accs.append(accuracy_score(y_test, y_pred))
    
    results_skf[name] = {
        'AUC': f"{np.mean(aucs):.3f} ± {np.std(aucs):.3f}",
        'F1': f"{np.mean(f1s):.3f} ± {np.std(f1s):.3f}",
        'Accuracy': f"{np.mean(accs):.3f} ± {np.std(accs):.3f}",
        'AUC_mean': np.mean(aucs)
    }
    print(f"    {name}: AUC={np.mean(aucs):.3f}±{np.std(aucs):.3f}, "
          f"F1={np.mean(f1s):.3f}, Acc={np.mean(accs):.3f}")

# B) Leave-One-Study-Out CV
print("\n  --- Leave-One-Study-Out Cross-Validation ---")
logo = LeaveOneGroupOut()

results_loso = {}
for name, clf in classifiers.items():
    aucs, f1s, accs = [], [], []
    for train_idx, test_idx in logo.split(X_final, y, groups):
        X_train, X_test = X_final.iloc[train_idx], X_final.iloc[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        # Skip if test set has only one class
        if len(np.unique(y_test)) < 2:
            continue
        
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        y_prob = clf.predict_proba(X_test)[:, 1]
        
        try:
            aucs.append(roc_auc_score(y_test, y_prob))
        except:
            pass
        f1s.append(f1_score(y_test, y_pred, zero_division=0))
        accs.append(accuracy_score(y_test, y_pred))
    
    if aucs:
        results_loso[name] = {
            'AUC': f"{np.mean(aucs):.3f} ± {np.std(aucs):.3f}",
            'F1': f"{np.mean(f1s):.3f} ± {np.std(f1s):.3f}",
            'Accuracy': f"{np.mean(accs):.3f} ± {np.std(accs):.3f}",
        }
        print(f"    {name}: AUC={np.mean(aucs):.3f}±{np.std(aucs):.3f}, "
              f"F1={np.mean(f1s):.3f}, Acc={np.mean(accs):.3f}")

# ============ 5. SHAP Explainability ============
print("\n[5/6] SHAP explainability analysis...")

# Train best model on full data for SHAP
best_model_name = max(results_skf, key=lambda k: results_skf[k]['AUC_mean'])
print(f"  Best model: {best_model_name}")

best_clf = classifiers[best_model_name]
best_clf.fit(X_final, y)

if HAS_SHAP:
    if 'Forest' in best_model_name or 'XGBoost' in best_model_name or 'Gradient' in best_model_name:
        explainer = shap.TreeExplainer(best_clf)
    else:
        explainer = shap.LinearExplainer(best_clf, X_final)
    
    shap_values = explainer.shap_values(X_final)
    
    # Get feature importance from SHAP
    if isinstance(shap_values, list):
        shap_importance = np.abs(shap_values[1]).mean(axis=0)
    else:
        shap_importance = np.abs(shap_values).mean(axis=0)
    
    shap_df = pd.DataFrame({
        'gene': X_final.columns,
        'shap_importance': shap_importance
    }).sort_values('shap_importance', ascending=False)
    
    shap_df.to_csv(os.path.join(RESULTS_DIR, "shap_feature_importance.csv"), index=False)
    print(f"  Top 10 genes by SHAP importance:")
    print(shap_df.head(10).to_string(index=False))
else:
    # Use model's built-in feature importance
    if hasattr(best_clf, 'feature_importances_'):
        importance = best_clf.feature_importances_
        imp_df = pd.DataFrame({
            'gene': X_final.columns,
            'importance': importance
        }).sort_values('importance', ascending=False)
        imp_df.to_csv(os.path.join(RESULTS_DIR, "feature_importance.csv"), index=False)
        print(f"  Top 10 genes by importance:")
        print(imp_df.head(10).to_string(index=False))

# ============ 6. Save Results ============
print("\n[6/6] Saving results...")

# Results summary
results_df = pd.DataFrame(results_skf).T
results_df.to_csv(os.path.join(RESULTS_DIR, "cv_results_stratified_5fold.csv"))

if results_loso:
    loso_df = pd.DataFrame(results_loso).T
    loso_df.to_csv(os.path.join(RESULTS_DIR, "cv_results_leave_one_study_out.csv"))

# Save trained model info
with open(os.path.join(RESULTS_DIR, "MODEL_REPORT.txt"), 'w') as f:
    f.write("LONG COVID PERSISTENCE PREDICTION - MODEL REPORT\n")
    f.write("=" * 60 + "\n\n")
    f.write(f"Best Model: {best_model_name}\n")
    f.write(f"Features: {X_final.shape[1]} mitochondrial genes\n")
    f.write(f"Samples: {X_final.shape[0]} (Persistent={y.sum()}, Recovered={len(y)-y.sum()})\n\n")
    f.write("Stratified 5-Fold CV Results:\n")
    f.write("-" * 40 + "\n")
    for name, res in results_skf.items():
        f.write(f"  {name}: AUC={res['AUC']}, F1={res['F1']}, Acc={res['Accuracy']}\n")
    if results_loso:
        f.write(f"\nLeave-One-Study-Out CV Results:\n")
        f.write("-" * 40 + "\n")
        for name, res in results_loso.items():
            f.write(f"  {name}: AUC={res['AUC']}, F1={res['F1']}, Acc={res['Accuracy']}\n")

print(f"\nResults saved to: {RESULTS_DIR}/")
print("DONE!")
