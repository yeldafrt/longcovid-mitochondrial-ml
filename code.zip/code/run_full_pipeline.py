#!/usr/bin/env python3
"""
=============================================================================
LONG COVID MITOCHONDRIAL DYSFUNCTION - FULL ML PIPELINE
=============================================================================
Comprehensive machine learning pipeline with:
1. Data loading & batch correction
2. Nested Cross-Validation (model selection + hyperparameter tuning)
3. Gap Nested Cross-Validation (temporal leakage check)
4. Permutation Test (statistical significance)
5. Data Leakage Detection
6. Hyperparameter Sensitivity Analysis
7. Ablation Study (feature importance)
8. Learning Curves (overfitting detection)
9. SHAP Explainability Analysis
10. Final model training & saving

All results, plots data, logs, npy arrays saved.
=============================================================================
"""
import pandas as pd
import numpy as np
import os
import sys
import json
import time
import logging
import warnings
import joblib
from datetime import datetime

from sklearn.model_selection import (StratifiedKFold, LeaveOneGroupOut, 
                                      GridSearchCV, RandomizedSearchCV,
                                      cross_val_score, learning_curve,
                                      permutation_test_score)
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (roc_auc_score, f1_score, accuracy_score, 
                             precision_score, recall_score, 
                             classification_report, confusion_matrix, 
                             roc_curve, precision_recall_curve,
                             average_precision_score, matthews_corrcoef)
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.inspection import permutation_importance
from xgboost import XGBClassifier
import shap
from scipy.stats import ttest_ind, wilcoxon

warnings.filterwarnings('ignore')

# ============================================================================
# SETUP
# ============================================================================
SEED = 42
np.random.seed(SEED)

# Directories
BASE_DIR = "/home/ubuntu/model_project"
DATA_DIR = os.path.join(BASE_DIR, "dataset")
OUT_DIR = os.path.join(BASE_DIR, "results")
LOG_DIR = os.path.join(OUT_DIR, "logs")
NPY_DIR = os.path.join(OUT_DIR, "npy_arrays")
MODEL_DIR = os.path.join(OUT_DIR, "models")
PLOT_DIR = os.path.join(OUT_DIR, "plot_data")
METRICS_DIR = os.path.join(OUT_DIR, "metrics")

for d in [OUT_DIR, LOG_DIR, NPY_DIR, MODEL_DIR, PLOT_DIR, METRICS_DIR]:
    os.makedirs(d, exist_ok=True)

# Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, 'pipeline.log')),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

logger.info("=" * 70)
logger.info("LONG COVID ML PIPELINE STARTED")
logger.info(f"Timestamp: {datetime.now().isoformat()}")
logger.info("=" * 70)

# ============================================================================
# 1. DATA LOADING
# ============================================================================
logger.info("\n[1/10] LOADING DATA...")

X_df = pd.read_csv(os.path.join(DATA_DIR, "X_mito_genes_log2cpm.csv.gz"), 
                   compression='gzip', index_col=0).T  # samples x genes
metadata = pd.read_csv(os.path.join(DATA_DIR, "y_metadata_binary.csv"))
mito_info = pd.read_csv(os.path.join(DATA_DIR, "mitochondrial_genes_in_dataset.csv"))

y = metadata['binary_numeric'].values
groups = metadata['dataset'].values
batch = metadata['batch'].values
sample_ids = metadata['sample_id'].values
gene_names = X_df.columns.tolist()

logger.info(f"  X shape: {X_df.shape} (samples x genes)")
logger.info(f"  y: Persistent={y.sum()}, Recovered={len(y)-y.sum()}")
logger.info(f"  Datasets: {np.unique(groups).tolist()}")
logger.info(f"  Batches: {np.unique(batch).tolist()}")

# Save raw data arrays
np.save(os.path.join(NPY_DIR, "X_raw.npy"), X_df.values)
np.save(os.path.join(NPY_DIR, "y.npy"), y)
np.save(os.path.join(NPY_DIR, "groups.npy"), groups)

# ============================================================================
# 2. BATCH EFFECT CORRECTION
# ============================================================================
logger.info("\n[2/10] BATCH EFFECT CORRECTION...")

# Z-score standardization within each batch
X_corrected = X_df.copy()
for b in np.unique(batch):
    mask = batch == b
    if mask.sum() > 1:
        scaler = StandardScaler()
        X_corrected.iloc[mask] = scaler.fit_transform(X_df.iloc[mask])
    else:
        X_corrected.iloc[mask] = 0  # single sample batch

X = X_corrected.values
logger.info(f"  Batch-corrected X shape: {X.shape}")
np.save(os.path.join(NPY_DIR, "X_batch_corrected.npy"), X)

# ============================================================================
# 3. NESTED CROSS-VALIDATION (Model Selection)
# ============================================================================
logger.info("\n[3/10] NESTED CROSS-VALIDATION...")

# Define models and hyperparameter grids
models_params = {
    'XGBoost': {
        'model': XGBClassifier(random_state=SEED, eval_metric='logloss', verbosity=0, use_label_encoder=False),
        'params': {
            'n_estimators': [50, 100, 200],
            'max_depth': [3, 4, 5, 6],
            'learning_rate': [0.01, 0.05, 0.1],
            'subsample': [0.7, 0.8, 0.9],
            'colsample_bytree': [0.7, 0.8, 0.9],
            'min_child_weight': [1, 3, 5],
            'scale_pos_weight': [len(y[y==0])/len(y[y==1])]
        }
    },
    'Random_Forest': {
        'model': RandomForestClassifier(random_state=SEED, class_weight='balanced'),
        'params': {
            'n_estimators': [100, 200, 300],
            'max_depth': [4, 6, 8, 10, None],
            'min_samples_split': [2, 5, 10],
            'min_samples_leaf': [1, 2, 4],
            'max_features': ['sqrt', 'log2', 0.5]
        }
    },
    'Gradient_Boosting': {
        'model': GradientBoostingClassifier(random_state=SEED),
        'params': {
            'n_estimators': [50, 100, 200],
            'max_depth': [3, 4, 5],
            'learning_rate': [0.01, 0.05, 0.1],
            'subsample': [0.7, 0.8, 0.9],
            'min_samples_leaf': [1, 2, 5]
        }
    },
    'SVM': {
        'model': SVC(probability=True, class_weight='balanced', random_state=SEED),
        'params': {
            'C': [0.01, 0.1, 1, 10, 100],
            'gamma': ['scale', 'auto', 0.01, 0.001],
            'kernel': ['rbf', 'linear']
        }
    },
    'Logistic_Regression': {
        'model': LogisticRegression(max_iter=2000, class_weight='balanced', random_state=SEED),
        'params': {
            'C': [0.001, 0.01, 0.1, 1, 10, 100],
            'penalty': ['l1', 'l2'],
            'solver': ['saga']
        }
    }
}

# Outer CV: 5-fold stratified
outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
# Inner CV: 3-fold stratified
inner_cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=SEED)

nested_results = {}
all_fold_predictions = {}

for model_name, mp in models_params.items():
    logger.info(f"\n  Training {model_name}...")
    
    outer_aucs = []
    outer_f1s = []
    outer_accs = []
    outer_precisions = []
    outer_recalls = []
    outer_mccs = []
    fold_y_true = []
    fold_y_pred = []
    fold_y_prob = []
    best_params_per_fold = []
    
    for fold_idx, (train_idx, test_idx) in enumerate(outer_cv.split(X, y)):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        # Inner CV for hyperparameter tuning
        search = RandomizedSearchCV(
            mp['model'], mp['params'], 
            n_iter=30, cv=inner_cv, scoring='roc_auc',
            random_state=SEED, n_jobs=-1
        )
        search.fit(X_train, y_train)
        
        # Predict on outer test set
        y_pred = search.predict(X_test)
        y_prob = search.predict_proba(X_test)[:, 1]
        
        auc = roc_auc_score(y_test, y_prob)
        f1 = f1_score(y_test, y_pred)
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        mcc = matthews_corrcoef(y_test, y_pred)
        
        outer_aucs.append(auc)
        outer_f1s.append(f1)
        outer_accs.append(acc)
        outer_precisions.append(prec)
        outer_recalls.append(rec)
        outer_mccs.append(mcc)
        fold_y_true.extend(y_test.tolist())
        fold_y_pred.extend(y_pred.tolist())
        fold_y_prob.extend(y_prob.tolist())
        best_params_per_fold.append(search.best_params_)
        
        logger.info(f"    Fold {fold_idx+1}: AUC={auc:.4f}, F1={f1:.4f}, MCC={mcc:.4f}")
    
    nested_results[model_name] = {
        'AUC_mean': np.mean(outer_aucs),
        'AUC_std': np.std(outer_aucs),
        'F1_mean': np.mean(outer_f1s),
        'F1_std': np.std(outer_f1s),
        'Accuracy_mean': np.mean(outer_accs),
        'Accuracy_std': np.std(outer_accs),
        'Precision_mean': np.mean(outer_precisions),
        'Precision_std': np.std(outer_precisions),
        'Recall_mean': np.mean(outer_recalls),
        'Recall_std': np.std(outer_recalls),
        'MCC_mean': np.mean(outer_mccs),
        'MCC_std': np.std(outer_mccs),
        'best_params': best_params_per_fold,
        'fold_aucs': outer_aucs
    }
    
    all_fold_predictions[model_name] = {
        'y_true': fold_y_true,
        'y_pred': fold_y_pred,
        'y_prob': fold_y_prob
    }
    
    logger.info(f"  {model_name}: AUC={np.mean(outer_aucs):.4f}±{np.std(outer_aucs):.4f}, "
                f"F1={np.mean(outer_f1s):.4f}±{np.std(outer_f1s):.4f}, "
                f"MCC={np.mean(outer_mccs):.4f}±{np.std(outer_mccs):.4f}")

# Save nested CV results
nested_df = pd.DataFrame({k: {m: f"{v[m+'_mean']:.4f}±{v[m+'_std']:.4f}" 
                               for m in ['AUC', 'F1', 'Accuracy', 'Precision', 'Recall', 'MCC']}
                          for k, v in nested_results.items()}).T
nested_df.to_csv(os.path.join(METRICS_DIR, "nested_cv_results.csv"))
logger.info(f"\n  Nested CV results saved.")

# Save fold predictions
for model_name, preds in all_fold_predictions.items():
    np.save(os.path.join(NPY_DIR, f"nested_cv_{model_name}_y_true.npy"), preds['y_true'])
    np.save(os.path.join(NPY_DIR, f"nested_cv_{model_name}_y_pred.npy"), preds['y_pred'])
    np.save(os.path.join(NPY_DIR, f"nested_cv_{model_name}_y_prob.npy"), preds['y_prob'])

# Determine best model
best_model_name = max(nested_results, key=lambda k: nested_results[k]['AUC_mean'])
logger.info(f"\n  BEST MODEL: {best_model_name} (AUC={nested_results[best_model_name]['AUC_mean']:.4f})")

# ============================================================================
# 4. LEAVE-ONE-STUDY-OUT CROSS-VALIDATION
# ============================================================================
logger.info("\n[4/10] LEAVE-ONE-STUDY-OUT CROSS-VALIDATION...")

logo = LeaveOneGroupOut()
loso_results = {}

for model_name, mp in models_params.items():
    aucs, f1s, accs, mccs = [], [], [], []
    study_results = []
    
    for train_idx, test_idx in logo.split(X, y, groups):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        test_study = groups[test_idx[0]]
        
        if len(np.unique(y_test)) < 2:
            continue
        
        # Use best params from nested CV (first fold as representative)
        model = mp['model'].__class__(**{**mp['model'].get_params(), **nested_results[model_name]['best_params'][0]})
        model.fit(X_train, y_train)
        
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]
        
        try:
            auc = roc_auc_score(y_test, y_prob)
            aucs.append(auc)
        except:
            auc = None
        
        f1 = f1_score(y_test, y_pred, zero_division=0)
        acc = accuracy_score(y_test, y_pred)
        mcc = matthews_corrcoef(y_test, y_pred)
        f1s.append(f1)
        accs.append(acc)
        mccs.append(mcc)
        
        study_results.append({
            'study': test_study, 'n_samples': len(test_idx),
            'AUC': auc, 'F1': f1, 'Accuracy': acc, 'MCC': mcc
        })
    
    loso_results[model_name] = {
        'AUC_mean': np.mean(aucs) if aucs else None,
        'AUC_std': np.std(aucs) if aucs else None,
        'F1_mean': np.mean(f1s),
        'Accuracy_mean': np.mean(accs),
        'MCC_mean': np.mean(mccs),
        'per_study': study_results
    }
    
    if aucs:
        logger.info(f"  {model_name}: AUC={np.mean(aucs):.4f}±{np.std(aucs):.4f}, F1={np.mean(f1s):.4f}")

# Save LOSO results
loso_detail = []
for model_name, res in loso_results.items():
    for sr in res['per_study']:
        sr['model'] = model_name
        loso_detail.append(sr)
pd.DataFrame(loso_detail).to_csv(os.path.join(METRICS_DIR, "loso_cv_per_study.csv"), index=False)

# ============================================================================
# 5. GAP NESTED CROSS-VALIDATION
# ============================================================================
logger.info("\n[5/10] GAP NESTED CROSS-VALIDATION...")
# Gap CV: Leave a gap between train and test to prevent temporal leakage
# We simulate this by leaving out adjacent folds

gap_results = {}
n_splits_gap = 5

for model_name in [best_model_name]:
    mp = models_params[model_name]
    gap_aucs = []
    
    # Sort by dataset (proxy for temporal order)
    sort_idx = np.argsort(groups)
    X_sorted = X[sort_idx]
    y_sorted = y[sort_idx]
    
    fold_size = len(y_sorted) // n_splits_gap
    
    for i in range(n_splits_gap):
        test_start = i * fold_size
        test_end = (i + 1) * fold_size if i < n_splits_gap - 1 else len(y_sorted)
        
        # Gap: remove 10% of samples adjacent to test set
        gap_size = max(1, fold_size // 10)
        
        test_idx = list(range(test_start, test_end))
        gap_before = list(range(max(0, test_start - gap_size), test_start))
        gap_after = list(range(test_end, min(len(y_sorted), test_end + gap_size)))
        
        exclude = set(test_idx + gap_before + gap_after)
        train_idx = [j for j in range(len(y_sorted)) if j not in exclude]
        
        if len(train_idx) < 10 or len(test_idx) < 5:
            continue
        
        X_train_g, X_test_g = X_sorted[train_idx], X_sorted[test_idx]
        y_train_g, y_test_g = y_sorted[train_idx], y_sorted[test_idx]
        
        if len(np.unique(y_test_g)) < 2:
            continue
        
        model = mp['model'].__class__(**{**mp['model'].get_params(), **nested_results[model_name]['best_params'][0]})
        model.fit(X_train_g, y_train_g)
        y_prob_g = model.predict_proba(X_test_g)[:, 1]
        
        try:
            auc = roc_auc_score(y_test_g, y_prob_g)
            gap_aucs.append(auc)
        except:
            pass
    
    gap_results[model_name] = {
        'AUC_mean': np.mean(gap_aucs) if gap_aucs else None,
        'AUC_std': np.std(gap_aucs) if gap_aucs else None,
        'fold_aucs': gap_aucs
    }
    logger.info(f"  {model_name} Gap CV: AUC={np.mean(gap_aucs):.4f}±{np.std(gap_aucs):.4f}")

np.save(os.path.join(NPY_DIR, "gap_cv_aucs.npy"), gap_aucs)

# ============================================================================
# 6. PERMUTATION TEST
# ============================================================================
logger.info("\n[6/10] PERMUTATION TEST (n=200)...")

mp = models_params[best_model_name]
best_model_instance = mp['model'].__class__(**{**mp['model'].get_params(), **nested_results[best_model_name]['best_params'][0]})

cv_perm = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
score, perm_scores, pvalue = permutation_test_score(
    best_model_instance, X, y, scoring='roc_auc', 
    cv=cv_perm, n_permutations=200, random_state=SEED, n_jobs=-1
)

logger.info(f"  True score: {score:.4f}")
logger.info(f"  Permutation mean: {np.mean(perm_scores):.4f}±{np.std(perm_scores):.4f}")
logger.info(f"  P-value: {pvalue:.6f}")

np.save(os.path.join(NPY_DIR, "permutation_scores.npy"), perm_scores)
perm_result = {
    'true_score': float(score),
    'perm_mean': float(np.mean(perm_scores)),
    'perm_std': float(np.std(perm_scores)),
    'p_value': float(pvalue),
    'n_permutations': 200
}
with open(os.path.join(METRICS_DIR, "permutation_test.json"), 'w') as f:
    json.dump(perm_result, f, indent=2)

# ============================================================================
# 7. DATA LEAKAGE DETECTION
# ============================================================================
logger.info("\n[7/10] DATA LEAKAGE DETECTION...")

leakage_results = {}

# Test 1: Compare train vs test performance (overfitting indicator)
train_aucs = []
test_aucs = []
for train_idx, test_idx in outer_cv.split(X, y):
    model = mp['model'].__class__(**{**mp['model'].get_params(), **nested_results[best_model_name]['best_params'][0]})
    model.fit(X[train_idx], y[train_idx])
    
    train_prob = model.predict_proba(X[train_idx])[:, 1]
    test_prob = model.predict_proba(X[test_idx])[:, 1]
    
    train_aucs.append(roc_auc_score(y[train_idx], train_prob))
    test_aucs.append(roc_auc_score(y[test_idx], test_prob))

train_test_gap = np.mean(train_aucs) - np.mean(test_aucs)
leakage_results['train_auc_mean'] = float(np.mean(train_aucs))
leakage_results['test_auc_mean'] = float(np.mean(test_aucs))
leakage_results['train_test_gap'] = float(train_test_gap)
leakage_results['gap_acceptable'] = bool(train_test_gap < 0.15)  # <15% gap is acceptable

logger.info(f"  Train AUC: {np.mean(train_aucs):.4f}±{np.std(train_aucs):.4f}")
logger.info(f"  Test AUC: {np.mean(test_aucs):.4f}±{np.std(test_aucs):.4f}")
logger.info(f"  Gap: {train_test_gap:.4f} ({'ACCEPTABLE' if train_test_gap < 0.15 else 'WARNING'})")

# Test 2: Shuffled labels should give ~0.5 AUC
y_shuffled = y.copy()
np.random.shuffle(y_shuffled)
shuffled_scores = cross_val_score(best_model_instance, X, y_shuffled, cv=5, scoring='roc_auc')
leakage_results['shuffled_auc_mean'] = float(np.mean(shuffled_scores))
leakage_results['shuffled_acceptable'] = bool(np.mean(shuffled_scores) < 0.55)

logger.info(f"  Shuffled labels AUC: {np.mean(shuffled_scores):.4f} (should be ~0.5)")

# Test 3: Random features should give ~0.5 AUC
X_random = np.random.randn(*X.shape)
random_scores = cross_val_score(best_model_instance, X_random, y, cv=5, scoring='roc_auc')
leakage_results['random_features_auc_mean'] = float(np.mean(random_scores))
leakage_results['random_acceptable'] = bool(np.mean(random_scores) < 0.55)

logger.info(f"  Random features AUC: {np.mean(random_scores):.4f} (should be ~0.5)")

with open(os.path.join(METRICS_DIR, "data_leakage_detection.json"), 'w') as f:
    json.dump(leakage_results, f, indent=2)

np.save(os.path.join(NPY_DIR, "leakage_train_aucs.npy"), train_aucs)
np.save(os.path.join(NPY_DIR, "leakage_test_aucs.npy"), test_aucs)

# ============================================================================
# 8. HYPERPARAMETER SENSITIVITY ANALYSIS
# ============================================================================
logger.info("\n[8/10] HYPERPARAMETER SENSITIVITY ANALYSIS...")

hp_sensitivity = {}

if best_model_name == 'XGBoost':
    param_ranges = {
        'n_estimators': [25, 50, 75, 100, 150, 200, 300, 400],
        'max_depth': [2, 3, 4, 5, 6, 7, 8, 10],
        'learning_rate': [0.001, 0.005, 0.01, 0.03, 0.05, 0.1, 0.2, 0.3],
        'subsample': [0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
    }
elif best_model_name == 'Random_Forest':
    param_ranges = {
        'n_estimators': [25, 50, 100, 150, 200, 300, 400, 500],
        'max_depth': [2, 3, 4, 5, 6, 8, 10, None],
        'min_samples_split': [2, 3, 5, 7, 10, 15, 20],
        'min_samples_leaf': [1, 2, 3, 4, 5, 7, 10],
    }
else:
    param_ranges = {}

base_params = nested_results[best_model_name]['best_params'][0].copy()

for param_name, values in param_ranges.items():
    scores = []
    for val in values:
        try:
            test_params = base_params.copy()
            test_params[param_name] = val
            model = models_params[best_model_name]['model'].__class__(
                **{**models_params[best_model_name]['model'].get_params(), **test_params}
            )
            cv_scores = cross_val_score(model, X, y, cv=5, scoring='roc_auc')
            scores.append(float(np.mean(cv_scores)))
        except:
            scores.append(None)
    
    hp_sensitivity[param_name] = {
        'values': [str(v) for v in values],
        'scores': scores
    }
    logger.info(f"  {param_name}: best={values[np.argmax([s for s in scores if s is not None])]}")

with open(os.path.join(PLOT_DIR, "hyperparameter_sensitivity.json"), 'w') as f:
    json.dump(hp_sensitivity, f, indent=2)

# ============================================================================
# 9. ABLATION STUDY
# ============================================================================
logger.info("\n[9/10] ABLATION STUDY...")

# Train final model with best params
final_model = models_params[best_model_name]['model'].__class__(
    **{**models_params[best_model_name]['model'].get_params(), **nested_results[best_model_name]['best_params'][0]}
)
final_model.fit(X, y)

# Feature importance from model
if hasattr(final_model, 'feature_importances_'):
    model_importance = final_model.feature_importances_
else:
    model_importance = np.abs(final_model.coef_[0]) if hasattr(final_model, 'coef_') else np.zeros(X.shape[1])

importance_df = pd.DataFrame({
    'gene': gene_names,
    'importance': model_importance
}).sort_values('importance', ascending=False)
importance_df.to_csv(os.path.join(METRICS_DIR, "feature_importance_model.csv"), index=False)

# Permutation importance (more reliable)
perm_imp = permutation_importance(final_model, X, y, n_repeats=30, random_state=SEED, scoring='roc_auc')
perm_imp_df = pd.DataFrame({
    'gene': gene_names,
    'importance_mean': perm_imp.importances_mean,
    'importance_std': perm_imp.importances_std
}).sort_values('importance_mean', ascending=False)
perm_imp_df.to_csv(os.path.join(METRICS_DIR, "feature_importance_permutation.csv"), index=False)
np.save(os.path.join(NPY_DIR, "permutation_importances.npy"), perm_imp.importances)

# Ablation: Remove top features one by one
logger.info("  Running ablation (removing top features)...")
top_features = importance_df.head(30)['gene'].tolist()
ablation_results = []

# Baseline (all features)
baseline_score = np.mean(cross_val_score(final_model.__class__(
    **{**models_params[best_model_name]['model'].get_params(), **nested_results[best_model_name]['best_params'][0]}
), X, y, cv=5, scoring='roc_auc'))
ablation_results.append({'removed': 'None (baseline)', 'n_features': X.shape[1], 'AUC': baseline_score})

for i, gene in enumerate(top_features[:20]):
    gene_idx = gene_names.index(gene)
    X_ablated = np.delete(X, gene_idx, axis=1)
    
    model_abl = final_model.__class__(
        **{**models_params[best_model_name]['model'].get_params(), **nested_results[best_model_name]['best_params'][0]}
    )
    abl_score = np.mean(cross_val_score(model_abl, X_ablated, y, cv=5, scoring='roc_auc'))
    ablation_results.append({'removed': gene, 'n_features': X_ablated.shape[1], 'AUC': abl_score})
    logger.info(f"    Remove {gene}: AUC={abl_score:.4f} (Δ={baseline_score-abl_score:.4f})")

# Ablation: Progressive feature removal (top N features only)
progressive_ablation = []
for n_top in [5, 10, 15, 20, 30, 50, 75, 100, 149]:
    n_top = min(n_top, len(gene_names))
    top_idx = [gene_names.index(g) for g in importance_df.head(n_top)['gene'].tolist()]
    X_top = X[:, top_idx]
    
    model_prog = final_model.__class__(
        **{**models_params[best_model_name]['model'].get_params(), **nested_results[best_model_name]['best_params'][0]}
    )
    prog_score = np.mean(cross_val_score(model_prog, X_top, y, cv=5, scoring='roc_auc'))
    progressive_ablation.append({'n_features': n_top, 'AUC': prog_score})
    logger.info(f"    Top {n_top} features: AUC={prog_score:.4f}")

pd.DataFrame(ablation_results).to_csv(os.path.join(METRICS_DIR, "ablation_single_removal.csv"), index=False)
pd.DataFrame(progressive_ablation).to_csv(os.path.join(METRICS_DIR, "ablation_progressive.csv"), index=False)

# ============================================================================
# 10. LEARNING CURVES
# ============================================================================
logger.info("\n[10/10] LEARNING CURVES & SHAP EXPLAINABILITY...")

# Learning curves
train_sizes_abs, train_scores, test_scores = learning_curve(
    final_model.__class__(
        **{**models_params[best_model_name]['model'].get_params(), **nested_results[best_model_name]['best_params'][0]}
    ),
    X, y, cv=5, scoring='roc_auc',
    train_sizes=np.linspace(0.1, 1.0, 10),
    random_state=SEED, n_jobs=-1
)

np.save(os.path.join(NPY_DIR, "learning_curve_train_sizes.npy"), train_sizes_abs)
np.save(os.path.join(NPY_DIR, "learning_curve_train_scores.npy"), train_scores)
np.save(os.path.join(NPY_DIR, "learning_curve_test_scores.npy"), test_scores)

learning_curve_data = {
    'train_sizes': train_sizes_abs.tolist(),
    'train_mean': train_scores.mean(axis=1).tolist(),
    'train_std': train_scores.std(axis=1).tolist(),
    'test_mean': test_scores.mean(axis=1).tolist(),
    'test_std': test_scores.std(axis=1).tolist()
}
with open(os.path.join(PLOT_DIR, "learning_curves.json"), 'w') as f:
    json.dump(learning_curve_data, f, indent=2)

logger.info(f"  Learning curve: Train final={train_scores.mean(axis=1)[-1]:.4f}, Test final={test_scores.mean(axis=1)[-1]:.4f}")

# ============================================================================
# SHAP EXPLAINABILITY
# ============================================================================
logger.info("\n  SHAP Explainability Analysis...")

# SHAP values
if best_model_name in ['XGBoost', 'Random_Forest', 'Gradient_Boosting']:
    explainer = shap.TreeExplainer(final_model)
    shap_values = explainer.shap_values(X)
else:
    explainer = shap.LinearExplainer(final_model, X)
    shap_values = explainer.shap_values(X)

# Handle different SHAP output formats
if isinstance(shap_values, list):
    shap_vals = shap_values[1]  # Class 1 (Persistent)
elif shap_values.ndim == 3:
    shap_vals = shap_values[:, :, 1]  # 3D array: (samples, features, classes)
else:
    shap_vals = shap_values

np.save(os.path.join(NPY_DIR, "shap_values.npy"), shap_vals)
np.save(os.path.join(NPY_DIR, "shap_expected_value.npy"), 
        np.array(explainer.expected_value if not isinstance(explainer.expected_value, list) 
                 else explainer.expected_value[1]))

# SHAP feature importance
shap_importance = np.abs(shap_vals).mean(axis=0)
shap_imp_df = pd.DataFrame({
    'gene': gene_names,
    'shap_importance': shap_importance,
    'shap_mean_value': shap_vals.mean(axis=0)
}).sort_values('shap_importance', ascending=False)
shap_imp_df.to_csv(os.path.join(METRICS_DIR, "shap_feature_importance.csv"), index=False)

# SHAP interaction (top 10 features)
logger.info("  Computing SHAP interaction values for top features...")
top10_idx = [gene_names.index(g) for g in shap_imp_df.head(10)['gene'].tolist()]

# Save SHAP summary data for plotting
shap_summary_data = pd.DataFrame(shap_vals, columns=gene_names)
shap_summary_data.to_csv(os.path.join(PLOT_DIR, "shap_values_matrix.csv.gz"), compression='gzip', index=False)

# Per-sample SHAP for waterfall plots (save first 5 samples of each class)
for cls in [0, 1]:
    cls_idx = np.where(y == cls)[0][:5]
    for i, idx in enumerate(cls_idx):
        np.save(os.path.join(NPY_DIR, f"shap_sample_class{cls}_{i}.npy"), shap_vals[idx])

logger.info(f"  Top 10 SHAP features: {shap_imp_df.head(10)['gene'].tolist()}")

# ============================================================================
# ROC CURVE DATA (for all models)
# ============================================================================
logger.info("\n  Generating ROC curve data...")

roc_data = {}
for model_name, preds in all_fold_predictions.items():
    fpr, tpr, thresholds = roc_curve(preds['y_true'], preds['y_prob'])
    roc_data[model_name] = {
        'fpr': fpr.tolist(),
        'tpr': tpr.tolist(),
        'auc': float(roc_auc_score(preds['y_true'], preds['y_prob']))
    }
    np.save(os.path.join(NPY_DIR, f"roc_fpr_{model_name}.npy"), fpr)
    np.save(os.path.join(NPY_DIR, f"roc_tpr_{model_name}.npy"), tpr)

with open(os.path.join(PLOT_DIR, "roc_curves.json"), 'w') as f:
    json.dump(roc_data, f, indent=2)

# Precision-Recall curves
pr_data = {}
for model_name, preds in all_fold_predictions.items():
    precision, recall, _ = precision_recall_curve(preds['y_true'], preds['y_prob'])
    ap = average_precision_score(preds['y_true'], preds['y_prob'])
    pr_data[model_name] = {
        'precision': precision.tolist(),
        'recall': recall.tolist(),
        'average_precision': float(ap)
    }
    np.save(os.path.join(NPY_DIR, f"pr_precision_{model_name}.npy"), precision)
    np.save(os.path.join(NPY_DIR, f"pr_recall_{model_name}.npy"), recall)

with open(os.path.join(PLOT_DIR, "precision_recall_curves.json"), 'w') as f:
    json.dump(pr_data, f, indent=2)

# ============================================================================
# CONFUSION MATRICES
# ============================================================================
for model_name, preds in all_fold_predictions.items():
    cm = confusion_matrix(preds['y_true'], preds['y_pred'])
    np.save(os.path.join(NPY_DIR, f"confusion_matrix_{model_name}.npy"), cm)

# ============================================================================
# SAVE FINAL MODEL
# ============================================================================
logger.info("\n  Saving final model...")
joblib.dump(final_model, os.path.join(MODEL_DIR, f"best_model_{best_model_name}.joblib"))
joblib.dump(StandardScaler().fit(X), os.path.join(MODEL_DIR, "scaler.joblib"))

# Save model metadata
model_meta = {
    'best_model': best_model_name,
    'best_params': nested_results[best_model_name]['best_params'][0],
    'nested_cv_auc': nested_results[best_model_name]['AUC_mean'],
    'nested_cv_auc_std': nested_results[best_model_name]['AUC_std'],
    'n_features': X.shape[1],
    'n_samples': X.shape[0],
    'feature_names': gene_names,
    'timestamp': datetime.now().isoformat(),
    'seed': SEED
}
with open(os.path.join(MODEL_DIR, "model_metadata.json"), 'w') as f:
    json.dump(model_meta, f, indent=2, default=str)

# ============================================================================
# COMPREHENSIVE SUMMARY
# ============================================================================
logger.info("\n" + "=" * 70)
logger.info("PIPELINE COMPLETE - SUMMARY")
logger.info("=" * 70)

summary = {
    'best_model': best_model_name,
    'nested_cv': {k: {'AUC': f"{v['AUC_mean']:.4f}±{v['AUC_std']:.4f}",
                      'F1': f"{v['F1_mean']:.4f}±{v['F1_std']:.4f}",
                      'MCC': f"{v['MCC_mean']:.4f}±{v['MCC_std']:.4f}"}
                 for k, v in nested_results.items()},
    'loso_cv': {k: {'AUC': f"{v['AUC_mean']:.4f}" if v['AUC_mean'] else 'N/A'}
                for k, v in loso_results.items()},
    'gap_cv': gap_results,
    'permutation_test': perm_result,
    'data_leakage': leakage_results,
    'overfitting_assessment': {
        'train_test_gap': f"{train_test_gap:.4f}",
        'gap_acceptable': bool(train_test_gap < 0.15),
        'permutation_significant': bool(pvalue < 0.05),
        'shuffled_near_random': bool(np.mean(shuffled_scores) < 0.55),
        'random_features_near_random': bool(np.mean(random_scores) < 0.55),
        'conclusion': 'NO OVERFITTING DETECTED' if (train_test_gap < 0.15 and pvalue < 0.05) else 'POTENTIAL OVERFITTING'
    }
}

with open(os.path.join(OUT_DIR, "FULL_SUMMARY.json"), 'w') as f:
    json.dump(summary, f, indent=2, default=str)

logger.info(f"\n  Best Model: {best_model_name}")
logger.info(f"  Nested CV AUC: {nested_results[best_model_name]['AUC_mean']:.4f}±{nested_results[best_model_name]['AUC_std']:.4f}")
logger.info(f"  Permutation p-value: {pvalue:.6f}")
logger.info(f"  Train-Test Gap: {train_test_gap:.4f}")
logger.info(f"  Overfitting: {'NO' if train_test_gap < 0.15 and pvalue < 0.05 else 'POTENTIAL'}")
logger.info(f"\n  All results saved to: {OUT_DIR}/")
logger.info("=" * 70)
